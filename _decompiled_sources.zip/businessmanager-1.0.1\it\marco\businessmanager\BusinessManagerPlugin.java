/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.PluginCommand
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.java.JavaPlugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package it.marco.businessmanager;

import it.marco.businessmanager.command.BmCommand;
import it.marco.businessmanager.data.DataStore;
import it.marco.businessmanager.economy.EconomyService;
import it.marco.businessmanager.hook.LuckPermsHook;
import it.marco.businessmanager.service.SalaryScheduler;
import it.marco.businessmanager.util.MessageManager;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class BusinessManagerPlugin
extends JavaPlugin {
    private DataStore dataStore;
    private MessageManager messages;
    private EconomyService economyService;
    private LuckPermsHook luckPermsHook;
    private SalaryScheduler salaryScheduler;
    private BukkitTask autosaveTask;

    public void onEnable() {
        this.saveDefaultConfig();
        this.messages = new MessageManager(this);
        this.dataStore = new DataStore(this);
        this.dataStore.load();
        this.economyService = new EconomyService(this, this.dataStore);
        this.luckPermsHook = new LuckPermsHook(this);
        this.salaryScheduler = new SalaryScheduler(this, this.dataStore, this.economyService, this.messages);
        this.salaryScheduler.start();
        BmCommand command = new BmCommand(this);
        PluginCommand pluginCommand = this.getCommand("business");
        if (pluginCommand != null) {
            pluginCommand.setExecutor((CommandExecutor)command);
            pluginCommand.setTabCompleter((TabCompleter)command);
        }
        this.startAutosave();
        this.getLogger().info("BusinessManager avviato.");
    }

    public void onDisable() {
        if (this.autosaveTask != null) {
            this.autosaveTask.cancel();
        }
        if (this.salaryScheduler != null) {
            this.salaryScheduler.stop();
        }
        if (this.dataStore != null) {
            this.dataStore.save();
        }
        this.getLogger().info("BusinessManager fermato.");
    }

    public void reloadAll() {
        this.reloadConfig();
        this.messages.reload();
        this.economyService.reload();
        this.luckPermsHook.reload();
        this.dataStore.save();
        this.dataStore.load();
        this.salaryScheduler.start();
    }

    private void startAutosave() {
        int minutes;
        if (this.autosaveTask != null) {
            this.autosaveTask.cancel();
        }
        if ((minutes = this.getConfig().getInt("autosave-minutes", 5)) <= 0) {
            return;
        }
        this.autosaveTask = new BukkitRunnable(){

            public void run() {
                BusinessManagerPlugin.this.dataStore.save();
            }
        }.runTaskTimer((Plugin)this, (long)minutes * 60L * 20L, (long)minutes * 60L * 20L);
    }

    public DataStore getDataStore() {
        return this.dataStore;
    }

    public MessageManager getMessages() {
        return this.messages;
    }

    public EconomyService getEconomyService() {
        return this.economyService;
    }

    public LuckPermsHook getLuckPermsHook() {
        return this.luckPermsHook;
    }

    public SalaryScheduler getSalaryScheduler() {
        return this.salaryScheduler;
    }
}

