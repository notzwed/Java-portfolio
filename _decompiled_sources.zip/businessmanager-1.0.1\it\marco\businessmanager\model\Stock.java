/*
 * Decompiled with CFR 0.152.
 */
package it.marco.businessmanager.model;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class Stock {
    private String symbol;
    private String name;
    private int totalShares;
    private int availableShares;
    private double price;
    private long lastPriceChangeEpoch;
    private final Map<UUID, Integer> holders = new HashMap<UUID, Integer>();

    public String getSymbol() {
        return this.symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getTotalShares() {
        return this.totalShares;
    }

    public void setTotalShares(int totalShares) {
        this.totalShares = totalShares;
    }

    public int getAvailableShares() {
        return this.availableShares;
    }

    public void setAvailableShares(int availableShares) {
        this.availableShares = availableShares;
    }

    public double getPrice() {
        return this.price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public long getLastPriceChangeEpoch() {
        return this.lastPriceChangeEpoch;
    }

    public void setLastPriceChangeEpoch(long lastPriceChangeEpoch) {
        this.lastPriceChangeEpoch = lastPriceChangeEpoch;
    }

    public Map<UUID, Integer> getHolders() {
        return this.holders;
    }

    public int getHolderShares(UUID uuid) {
        return this.holders.getOrDefault(uuid, 0);
    }

    public void addShares(UUID uuid, int shares) {
        this.holders.put(uuid, this.getHolderShares(uuid) + shares);
    }

    public void removeShares(UUID uuid, int shares) {
        int current = this.getHolderShares(uuid) - shares;
        if (current <= 0) {
            this.holders.remove(uuid);
        } else {
            this.holders.put(uuid, current);
        }
    }
}

