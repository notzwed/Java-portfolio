/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.io.filefilter;

import github.scarsz.discordsrv.dependencies.commons.io.filefilter.AbstractFileFilter;
import github.scarsz.discordsrv.dependencies.commons.io.filefilter.IOFileFilter;
import java.io.File;
import java.io.Serializable;

public class FileFileFilter
extends AbstractFileFilter
implements Serializable {
    private static final long serialVersionUID = 5345244090827540862L;
    public static final IOFileFilter FILE = new FileFileFilter();

    protected FileFileFilter() {
    }

    @Override
    public boolean accept(File file) {
        return file.isFile();
    }
}

