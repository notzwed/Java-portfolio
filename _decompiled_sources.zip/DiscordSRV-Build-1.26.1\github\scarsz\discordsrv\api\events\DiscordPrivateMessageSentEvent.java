/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.api.events;

import github.scarsz.discordsrv.api.events.DiscordEvent;
import github.scarsz.discordsrv.dependencies.jda.api.JDA;
import github.scarsz.discordsrv.dependencies.jda.api.entities.Message;
import github.scarsz.discordsrv.dependencies.jda.api.entities.PrivateChannel;
import github.scarsz.discordsrv.dependencies.jda.api.entities.User;

public class DiscordPrivateMessageSentEvent
extends DiscordEvent {
    private final PrivateChannel channel;
    private final Message message;
    private final User recipient;

    public DiscordPrivateMessageSentEvent(JDA jda, Message message) {
        super(jda);
        this.channel = message.getPrivateChannel();
        this.message = message;
        this.recipient = this.channel.getUser();
    }

    public PrivateChannel getChannel() {
        return this.channel;
    }

    public Message getMessage() {
        return this.message;
    }

    public User getRecipient() {
        return this.recipient;
    }
}

