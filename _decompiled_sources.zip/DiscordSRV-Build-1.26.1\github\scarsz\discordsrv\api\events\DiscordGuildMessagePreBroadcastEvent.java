/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.CommandSender
 */
package github.scarsz.discordsrv.api.events;

import github.scarsz.discordsrv.api.events.Event;
import github.scarsz.discordsrv.dependencies.kyori.adventure.text.Component;
import java.util.List;
import org.bukkit.command.CommandSender;

public class DiscordGuildMessagePreBroadcastEvent
extends Event {
    private String channel;
    private Component message;
    private final List<? extends CommandSender> recipients;

    public DiscordGuildMessagePreBroadcastEvent(String channel, Component message, List<? extends CommandSender> recipients) {
        this.channel = channel;
        this.message = message;
        this.recipients = recipients;
    }

    public String getChannel() {
        return this.channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public Component getMessage() {
        return this.message;
    }

    public void setMessage(Component message) {
        this.message = message;
    }

    public List<? extends CommandSender> getRecipients() {
        return this.recipients;
    }
}

