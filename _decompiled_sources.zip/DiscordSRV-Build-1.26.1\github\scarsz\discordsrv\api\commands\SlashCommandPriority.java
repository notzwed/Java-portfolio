/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.api.commands;

public enum SlashCommandPriority {
    FIRST,
    EARLY,
    NORMAL,
    LATE,
    LAST;

}

