/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.codec;

public enum CodecPolicy {
    STRICT,
    LENIENT;

}

