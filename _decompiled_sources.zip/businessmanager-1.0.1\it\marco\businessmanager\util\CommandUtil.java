/*
 * Decompiled with CFR 0.152.
 */
package it.marco.businessmanager.util;

public class CommandUtil {
    private CommandUtil() {
    }

    public static Double parseDouble(String input) {
        try {
            return Double.parseDouble(input);
        }
        catch (NumberFormatException e) {
            return null;
        }
    }

    public static Integer parseInt(String input) {
        try {
            return Integer.parseInt(input);
        }
        catch (NumberFormatException e) {
            return null;
        }
    }
}

