/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.io.output;

import github.scarsz.discordsrv.dependencies.commons.io.output.ProxyCollectionWriter;
import java.io.Writer;
import java.util.Collection;

public class TeeWriter
extends ProxyCollectionWriter {
    public TeeWriter(Collection<Writer> writers) {
        super(writers);
    }

    public TeeWriter(Writer ... writers) {
        super(writers);
    }
}

