/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.io.input;

import github.scarsz.discordsrv.dependencies.commons.io.input.Tailer;
import github.scarsz.discordsrv.dependencies.commons.io.input.TailerListener;

public class TailerListenerAdapter
implements TailerListener {
    @Override
    public void init(Tailer tailer) {
    }

    @Override
    public void fileNotFound() {
    }

    @Override
    public void fileRotated() {
    }

    @Override
    public void handle(String line) {
    }

    @Override
    public void handle(Exception ex) {
    }

    public void endOfFileReached() {
    }
}

