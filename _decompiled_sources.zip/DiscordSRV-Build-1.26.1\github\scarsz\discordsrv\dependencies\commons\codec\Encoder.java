/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.codec;

import github.scarsz.discordsrv.dependencies.commons.codec.EncoderException;

public interface Encoder {
    public Object encode(Object var1) throws EncoderException;
}

