/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.collections4;

public interface Closure<T> {
    public void execute(T var1);
}

