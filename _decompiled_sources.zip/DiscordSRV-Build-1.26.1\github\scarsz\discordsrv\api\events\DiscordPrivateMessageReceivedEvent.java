/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.api.events;

import github.scarsz.discordsrv.api.events.DiscordEvent;
import github.scarsz.discordsrv.dependencies.jda.api.entities.Message;
import github.scarsz.discordsrv.dependencies.jda.api.entities.PrivateChannel;
import github.scarsz.discordsrv.dependencies.jda.api.entities.User;
import github.scarsz.discordsrv.dependencies.jda.api.events.message.priv.PrivateMessageReceivedEvent;

public class DiscordPrivateMessageReceivedEvent
extends DiscordEvent<PrivateMessageReceivedEvent> {
    private final User author;
    private final PrivateChannel channel;
    private final Message message;

    public DiscordPrivateMessageReceivedEvent(PrivateMessageReceivedEvent jdaEvent) {
        super(jdaEvent.getJDA(), jdaEvent);
        this.author = jdaEvent.getAuthor();
        this.channel = jdaEvent.getChannel();
        this.message = jdaEvent.getMessage();
    }

    public User getAuthor() {
        return this.author;
    }

    public PrivateChannel getChannel() {
        return this.channel;
    }

    public Message getMessage() {
        return this.message;
    }
}

