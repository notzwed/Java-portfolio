/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.io.output;

import github.scarsz.discordsrv.dependencies.commons.io.output.ClosedWriter;
import github.scarsz.discordsrv.dependencies.commons.io.output.ProxyWriter;
import java.io.Writer;

public class CloseShieldWriter
extends ProxyWriter {
    public static CloseShieldWriter wrap(Writer writer) {
        return new CloseShieldWriter(writer);
    }

    @Deprecated
    public CloseShieldWriter(Writer writer) {
        super(writer);
    }

    @Override
    public void close() {
        this.out = ClosedWriter.CLOSED_WRITER;
    }
}

