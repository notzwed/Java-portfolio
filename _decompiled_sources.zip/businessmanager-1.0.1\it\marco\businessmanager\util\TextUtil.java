/*
 * Decompiled with CFR 0.152.
 */
package it.marco.businessmanager.util;

public class TextUtil {
    private TextUtil() {
    }

    public static String join(String[] args, int start) {
        if (args.length <= start) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for (int i = start; i < args.length; ++i) {
            if (i > start) {
                sb.append(' ');
            }
            sb.append(args[i]);
        }
        return sb.toString();
    }
}

