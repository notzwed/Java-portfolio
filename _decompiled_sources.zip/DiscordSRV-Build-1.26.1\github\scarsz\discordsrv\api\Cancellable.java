/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.api;

public interface Cancellable {
    public boolean isCancelled();

    public void setCancelled(boolean var1);
}

