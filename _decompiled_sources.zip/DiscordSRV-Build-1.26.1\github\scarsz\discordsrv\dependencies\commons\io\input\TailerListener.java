/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.io.input;

import github.scarsz.discordsrv.dependencies.commons.io.input.Tailer;

public interface TailerListener {
    public void init(Tailer var1);

    public void fileNotFound();

    public void fileRotated();

    public void handle(String var1);

    public void handle(Exception var1);
}

