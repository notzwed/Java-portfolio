/*
 * Decompiled with CFR 0.152.
 */
package com.hrakaroo.glob;

public interface MatchingEngine {
    public boolean matches(String var1);

    public int matchingSizeInBytes();

    public int staticSizeInBytes();
}

