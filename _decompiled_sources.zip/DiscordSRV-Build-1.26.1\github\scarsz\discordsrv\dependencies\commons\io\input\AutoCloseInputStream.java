/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.io.input;

import github.scarsz.discordsrv.dependencies.commons.io.input.ClosedInputStream;
import github.scarsz.discordsrv.dependencies.commons.io.input.ProxyInputStream;
import java.io.IOException;
import java.io.InputStream;

public class AutoCloseInputStream
extends ProxyInputStream {
    public AutoCloseInputStream(InputStream in) {
        super(in);
    }

    @Override
    public void close() throws IOException {
        this.in.close();
        this.in = ClosedInputStream.CLOSED_INPUT_STREAM;
    }

    @Override
    protected void afterRead(int n) throws IOException {
        if (n == -1) {
            this.close();
        }
    }

    protected void finalize() throws Throwable {
        this.close();
        super.finalize();
    }
}

