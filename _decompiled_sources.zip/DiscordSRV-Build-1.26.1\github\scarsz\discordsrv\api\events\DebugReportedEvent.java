/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.api.events;

import github.scarsz.discordsrv.api.events.Event;

public class DebugReportedEvent
extends Event {
    private final String requester;
    private final String url;

    public DebugReportedEvent(String requester, String url) {
        this.requester = requester;
        this.url = url;
    }

    public String getRequester() {
        return this.requester;
    }

    public String getUrl() {
        return this.url;
    }
}

