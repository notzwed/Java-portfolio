/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.milkbowl.vault.economy.Economy
 *  org.bukkit.Bukkit
 *  org.bukkit.plugin.RegisteredServiceProvider
 */
package it.marco.businessmanager.economy;

import it.marco.businessmanager.BusinessManagerPlugin;
import it.marco.businessmanager.data.DataStore;
import it.marco.businessmanager.economy.InternalEconomy;
import it.marco.businessmanager.economy.PlayerEconomy;
import it.marco.businessmanager.economy.VaultEconomy;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;
import java.util.UUID;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.plugin.RegisteredServiceProvider;

public class EconomyService {
    private final BusinessManagerPlugin plugin;
    private final DataStore dataStore;
    private PlayerEconomy playerEconomy;
    private String currencySymbol;
    private DecimalFormat decimalFormat;
    private boolean allowNegative;

    public EconomyService(BusinessManagerPlugin plugin, DataStore dataStore) {
        this.plugin = plugin;
        this.dataStore = dataStore;
        this.reload();
    }

    public void reload() {
        boolean useVault = this.plugin.getConfig().getBoolean("economy.use-vault", true);
        this.allowNegative = this.plugin.getConfig().getBoolean("economy.allow-negative", false);
        this.currencySymbol = this.plugin.getConfig().getString("economy.currency-symbol", "$");
        String format = this.plugin.getConfig().getString("economy.decimal-format", "#,##0.00");
        DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.US);
        this.decimalFormat = new DecimalFormat(format, symbols);
        if (useVault) {
            RegisteredServiceProvider provider = Bukkit.getServicesManager().getRegistration(Economy.class);
            if (provider != null && provider.getProvider() != null) {
                this.playerEconomy = new VaultEconomy((Economy)provider.getProvider());
                this.plugin.getLogger().info("Vault economy agganciata.");
                return;
            }
            this.plugin.getLogger().warning("Vault non trovato, uso wallet interno.");
        }
        this.playerEconomy = new InternalEconomy(this.dataStore, this.allowNegative);
    }

    public boolean withdrawPlayer(UUID uuid, double amount) {
        return this.playerEconomy.withdraw(uuid, amount);
    }

    public void depositPlayer(UUID uuid, double amount) {
        this.playerEconomy.deposit(uuid, amount);
    }

    public double getPlayerBalance(UUID uuid) {
        return this.playerEconomy.getBalance(uuid);
    }

    public String format(double amount) {
        return this.currencySymbol + this.decimalFormat.format(amount);
    }

    public boolean isUsingInternal() {
        return this.playerEconomy instanceof InternalEconomy;
    }
}

