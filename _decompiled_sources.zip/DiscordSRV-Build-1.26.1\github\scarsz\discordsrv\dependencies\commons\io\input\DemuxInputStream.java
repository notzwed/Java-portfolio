/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.io.input;

import github.scarsz.discordsrv.dependencies.commons.io.IOUtils;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;

public class DemuxInputStream
extends InputStream {
    private final InheritableThreadLocal<InputStream> inputStreamLocal = new InheritableThreadLocal();

    public InputStream bindStream(InputStream input) {
        InputStream oldValue = (InputStream)this.inputStreamLocal.get();
        this.inputStreamLocal.set(input);
        return oldValue;
    }

    @Override
    public void close() throws IOException {
        IOUtils.close((Closeable)((Closeable)this.inputStreamLocal.get()));
    }

    @Override
    public int read() throws IOException {
        InputStream inputStream = (InputStream)this.inputStreamLocal.get();
        if (null != inputStream) {
            return inputStream.read();
        }
        return -1;
    }
}

