/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.codec;

import github.scarsz.discordsrv.dependencies.commons.codec.Encoder;
import github.scarsz.discordsrv.dependencies.commons.codec.EncoderException;

public interface BinaryEncoder
extends Encoder {
    public byte[] encode(byte[] var1) throws EncoderException;
}

