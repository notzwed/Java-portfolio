/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.api.events;

import github.scarsz.discordsrv.api.events.Event;

public class DiscordReadyEvent
extends Event {
}

