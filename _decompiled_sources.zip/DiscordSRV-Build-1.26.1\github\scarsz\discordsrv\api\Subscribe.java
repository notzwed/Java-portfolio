/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.api;

import github.scarsz.discordsrv.api.ListenerPriority;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(value=RetentionPolicy.RUNTIME)
@Target(value={ElementType.METHOD})
public @interface Subscribe {
    public ListenerPriority priority() default ListenerPriority.NORMAL;
}

