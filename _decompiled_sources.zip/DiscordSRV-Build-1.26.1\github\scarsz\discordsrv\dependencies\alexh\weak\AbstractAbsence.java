/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.alexh.weak;

import github.scarsz.discordsrv.dependencies.alexh.LiteJoiner;
import github.scarsz.discordsrv.dependencies.alexh.weak.Dynamic;
import github.scarsz.discordsrv.dependencies.alexh.weak.DynamicChild;
import github.scarsz.discordsrv.dependencies.alexh.weak.DynamicChildLogic;
import java.util.Objects;
import java.util.stream.Stream;

abstract class AbstractAbsence<Parent extends Dynamic>
implements DynamicChild {
    protected final Parent parent;
    protected final Object key;

    AbstractAbsence(Parent parent, Object key) {
        this.parent = parent;
        this.key = key;
    }

    public Parent parent() {
        return this.parent;
    }

    public Dynamic key() {
        return DynamicChild.key(this, this.key);
    }

    @Override
    public boolean isPresent() {
        return false;
    }

    @Override
    public Stream<Dynamic> children() {
        return Stream.empty();
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        AbstractAbsence other = (AbstractAbsence)o;
        return Objects.equals(this.parent, other.parent) && Objects.equals(this.key, other.key);
    }

    public int hashCode() {
        return Objects.hash(this.parent, this.key);
    }

    public String toString() {
        return LiteJoiner.on("->").join(DynamicChildLogic.using(this).getAscendingKeyChainWithRoot()) + ":absent";
    }
}

