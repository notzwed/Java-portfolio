/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  mineverse.Aust1n46.chat.api.events.VentureChatEvent
 *  org.bukkit.event.Cancellable
 */
package github.scarsz.discordsrv.api.events;

import github.scarsz.discordsrv.api.events.VentureChatMessageEvent;
import mineverse.Aust1n46.chat.api.events.VentureChatEvent;
import org.bukkit.event.Cancellable;

public class VentureChatMessagePostProcessEvent
extends VentureChatMessageEvent
implements Cancellable {
    private boolean cancelled;
    private String channel;
    private String processedMessage;

    public VentureChatMessagePostProcessEvent(String channel, String processedMessage, VentureChatEvent ventureChatEvent, boolean cancelled) {
        super(ventureChatEvent);
        this.channel = channel;
        this.processedMessage = processedMessage;
        this.setCancelled(cancelled);
    }

    public boolean isCancelled() {
        return this.cancelled;
    }

    public void setCancelled(boolean cancelled) {
        this.cancelled = cancelled;
    }

    public String getChannel() {
        return this.channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public String getProcessedMessage() {
        return this.processedMessage;
    }

    public void setProcessedMessage(String processedMessage) {
        this.processedMessage = processedMessage;
    }
}

