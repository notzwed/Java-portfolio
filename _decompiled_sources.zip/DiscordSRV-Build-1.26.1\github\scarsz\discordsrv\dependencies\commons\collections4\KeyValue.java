/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.collections4;

public interface KeyValue<K, V> {
    public K getKey();

    public V getValue();
}

