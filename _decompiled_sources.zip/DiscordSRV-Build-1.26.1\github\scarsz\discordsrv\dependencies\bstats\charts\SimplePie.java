/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.bstats.charts;

import github.scarsz.discordsrv.dependencies.bstats.charts.CustomChart;
import github.scarsz.discordsrv.dependencies.bstats.json.JsonObjectBuilder;
import java.util.concurrent.Callable;

public class SimplePie
extends CustomChart {
    private final Callable<String> callable;

    public SimplePie(String chartId, Callable<String> callable) {
        super(chartId);
        this.callable = callable;
    }

    @Override
    protected JsonObjectBuilder.JsonObject getChartData() throws Exception {
        String value = this.callable.call();
        if (value == null || value.isEmpty()) {
            return null;
        }
        return new JsonObjectBuilder().appendField("value", value).build();
    }
}

