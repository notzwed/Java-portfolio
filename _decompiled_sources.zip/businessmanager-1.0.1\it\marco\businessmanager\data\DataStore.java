/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.YamlConfiguration
 */
package it.marco.businessmanager.data;

import it.marco.businessmanager.BusinessManagerPlugin;
import it.marco.businessmanager.model.Company;
import it.marco.businessmanager.model.Investment;
import it.marco.businessmanager.model.PlayerAccount;
import it.marco.businessmanager.model.Role;
import it.marco.businessmanager.model.SalaryConfig;
import it.marco.businessmanager.model.Stock;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

public class DataStore {
    private final BusinessManagerPlugin plugin;
    private final File dataFile;
    private final Map<String, Company> companies = new HashMap<String, Company>();
    private final Map<UUID, PlayerAccount> accounts = new HashMap<UUID, PlayerAccount>();

    public DataStore(BusinessManagerPlugin plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "data.yml");
    }

    public void load() {
        ConfigurationSection accountsSec;
        YamlConfiguration config;
        ConfigurationSection companiesSec;
        this.companies.clear();
        this.accounts.clear();
        if (!this.dataFile.exists()) {
            try {
                this.plugin.getDataFolder().mkdirs();
                this.dataFile.createNewFile();
            }
            catch (IOException e) {
                this.plugin.getLogger().severe("Impossibile creare data.yml: " + e.getMessage());
                return;
            }
        }
        if ((companiesSec = (config = YamlConfiguration.loadConfiguration((File)this.dataFile)).getConfigurationSection("companies")) != null) {
            for (String id : companiesSec.getKeys(false)) {
                ConfigurationSection investmentsSec;
                ConfigurationSection stocksSec;
                ConfigurationSection c = companiesSec.getConfigurationSection(id);
                if (c == null) continue;
                Company company = new Company();
                company.setId(id.toLowerCase());
                company.setName(c.getString("name", id));
                String directorStr = c.getString("director", null);
                if (directorStr != null) {
                    try {
                        company.setDirector(UUID.fromString(directorStr));
                    }
                    catch (IllegalArgumentException illegalArgumentException) {
                        // empty catch block
                    }
                }
                company.setBalance(c.getDouble("balance", 0.0));
                SalaryConfig salary = this.createDefaultSalaryConfig();
                salary.setAmount(c.getDouble("salary.amount", salary.getAmount()));
                salary.setIntervalMinutes(c.getInt("salary.intervalMinutes", salary.getIntervalMinutes()));
                salary.setEnabled(c.getBoolean("salary.enabled", false));
                salary.setLastPaidEpoch(c.getLong("salary.lastPaidEpoch", 0L));
                List payRoles = c.getStringList("salary.payRoles");
                if (!payRoles.isEmpty()) {
                    salary.getPayRoles().clear();
                    for (Object role : payRoles) {
                        salary.getPayRoles().add(Role.fromString((String)role));
                    }
                }
                company.setSalaryConfig(salary);
                ConfigurationSection membersSec = c.getConfigurationSection("members");
                if (membersSec != null) {
                    Object role;
                    role = membersSec.getKeys(false).iterator();
                    while (role.hasNext()) {
                        String memberId = (String)role.next();
                        try {
                            UUID uuid = UUID.fromString(memberId);
                            Role role2 = Role.fromString(membersSec.getString(memberId));
                            company.addMember(uuid, role2);
                        }
                        catch (IllegalArgumentException uuid) {}
                    }
                }
                if (company.getDirector() != null) {
                    company.addMember(company.getDirector(), Role.DIRECTOR);
                }
                if ((stocksSec = c.getConfigurationSection("stocks")) != null) {
                    for (String symbol : stocksSec.getKeys(false)) {
                        ConfigurationSection s = stocksSec.getConfigurationSection(symbol);
                        if (s == null) continue;
                        Stock stock = new Stock();
                        stock.setSymbol(symbol.toUpperCase());
                        stock.setName(s.getString("name", symbol));
                        stock.setTotalShares(s.getInt("totalShares", 0));
                        stock.setAvailableShares(s.getInt("availableShares", stock.getTotalShares()));
                        stock.setPrice(s.getDouble("price", 0.0));
                        stock.setLastPriceChangeEpoch(s.getLong("lastPriceChangeEpoch", 0L));
                        ConfigurationSection holdersSec = s.getConfigurationSection("holders");
                        if (holdersSec != null) {
                            for (String holderId : holdersSec.getKeys(false)) {
                                try {
                                    UUID uuid = UUID.fromString(holderId);
                                    int shares = holdersSec.getInt(holderId, 0);
                                    if (shares <= 0) continue;
                                    stock.getHolders().put(uuid, shares);
                                }
                                catch (IllegalArgumentException illegalArgumentException) {}
                            }
                        }
                        company.addStock(stock);
                    }
                }
                if ((investmentsSec = c.getConfigurationSection("investments")) != null) {
                    for (String invId : investmentsSec.getKeys(false)) {
                        ConfigurationSection invSec = investmentsSec.getConfigurationSection(invId);
                        if (invSec == null) continue;
                        Investment investment = new Investment();
                        investment.setId(invId);
                        investment.setOptionId(invSec.getString("optionId", ""));
                        investment.setPrincipal(invSec.getDouble("principal", 0.0));
                        investment.setStartEpoch(invSec.getLong("startEpoch", 0L));
                        investment.setDurationMinutes(invSec.getInt("durationMinutes", 0));
                        investment.setReturnMultiplier(invSec.getDouble("returnMultiplier", 1.0));
                        investment.setClaimed(invSec.getBoolean("claimed", false));
                        company.addInvestment(investment);
                    }
                }
                this.companies.put(company.getId(), company);
            }
        }
        if ((accountsSec = config.getConfigurationSection("players")) != null) {
            for (String uuidStr : accountsSec.getKeys(false)) {
                try {
                    UUID uuid = UUID.fromString(uuidStr);
                    PlayerAccount account = new PlayerAccount();
                    account.setBalance(accountsSec.getDouble(uuidStr + ".balance", 0.0));
                    this.accounts.put(uuid, account);
                }
                catch (IllegalArgumentException illegalArgumentException) {}
            }
        }
    }

    public void save() {
        YamlConfiguration config = new YamlConfiguration();
        for (Company company : this.companies.values()) {
            String base = "companies." + company.getId();
            config.set(base + ".name", (Object)company.getName());
            config.set(base + ".director", company.getDirector() != null ? company.getDirector().toString() : null);
            config.set(base + ".balance", (Object)company.getBalance());
            SalaryConfig salary = company.getSalaryConfig();
            if (salary != null) {
                config.set(base + ".salary.amount", (Object)salary.getAmount());
                config.set(base + ".salary.intervalMinutes", (Object)salary.getIntervalMinutes());
                config.set(base + ".salary.enabled", (Object)salary.isEnabled());
                config.set(base + ".salary.lastPaidEpoch", (Object)salary.getLastPaidEpoch());
                ArrayList<String> roles = new ArrayList<String>();
                for (Role role : salary.getPayRoles()) {
                    roles.add(role.name());
                }
                config.set(base + ".salary.payRoles", roles);
            }
            for (Map.Entry<UUID, Role> entry : company.getMembers().entrySet()) {
                config.set(base + ".members." + entry.getKey().toString(), (Object)entry.getValue().name());
            }
            for (Stock stock : company.getStocks().values()) {
                String stockBase = base + ".stocks." + stock.getSymbol();
                config.set(stockBase + ".name", (Object)stock.getName());
                config.set(stockBase + ".totalShares", (Object)stock.getTotalShares());
                config.set(stockBase + ".availableShares", (Object)stock.getAvailableShares());
                config.set(stockBase + ".price", (Object)stock.getPrice());
                config.set(stockBase + ".lastPriceChangeEpoch", (Object)stock.getLastPriceChangeEpoch());
                for (Map.Entry<UUID, Integer> holder : stock.getHolders().entrySet()) {
                    config.set(stockBase + ".holders." + holder.getKey().toString(), (Object)holder.getValue());
                }
            }
            for (Investment investment : company.getInvestments().values()) {
                String invBase = base + ".investments." + investment.getId();
                config.set(invBase + ".optionId", (Object)investment.getOptionId());
                config.set(invBase + ".principal", (Object)investment.getPrincipal());
                config.set(invBase + ".startEpoch", (Object)investment.getStartEpoch());
                config.set(invBase + ".durationMinutes", (Object)investment.getDurationMinutes());
                config.set(invBase + ".returnMultiplier", (Object)investment.getReturnMultiplier());
                config.set(invBase + ".claimed", (Object)investment.isClaimed());
            }
        }
        for (Map.Entry entry : this.accounts.entrySet()) {
            config.set("players." + ((UUID)entry.getKey()).toString() + ".balance", (Object)((PlayerAccount)entry.getValue()).getBalance());
        }
        try {
            config.save(this.dataFile);
        }
        catch (IOException e) {
            this.plugin.getLogger().severe("Impossibile salvare data.yml: " + e.getMessage());
        }
    }

    public Company getCompany(String id) {
        if (id == null) {
            return null;
        }
        return this.companies.get(id.toLowerCase());
    }

    public void addCompany(Company company) {
        this.companies.put(company.getId(), company);
    }

    public Collection<Company> getCompanies() {
        return this.companies.values();
    }

    public boolean isValidCompanyId(String id) {
        String regex = this.plugin.getConfig().getString("company.id-regex", "^[a-zA-Z0-9_-]{3,16}$");
        return Pattern.compile(regex).matcher(id).matches();
    }

    public int getCompanyCountForDirector(UUID uuid) {
        int count = 0;
        for (Company company : this.companies.values()) {
            if (!uuid.equals(company.getDirector())) continue;
            ++count;
        }
        return count;
    }

    public PlayerAccount getOrCreateAccount(UUID uuid) {
        return this.accounts.computeIfAbsent(uuid, key -> {
            PlayerAccount account = new PlayerAccount();
            double start = this.plugin.getConfig().getDouble("economy.starting-balance", 0.0);
            account.setBalance(start);
            return account;
        });
    }

    private SalaryConfig createDefaultSalaryConfig() {
        SalaryConfig salary = new SalaryConfig();
        salary.setAmount(this.plugin.getConfig().getDouble("salary.default-amount", 100.0));
        salary.setIntervalMinutes(this.plugin.getConfig().getInt("salary.default-interval-minutes", 60));
        salary.setEnabled(false);
        salary.setLastPaidEpoch(0L);
        List roles = this.plugin.getConfig().getStringList("salary.default-pay-roles");
        if (roles != null) {
            for (String role : roles) {
                salary.getPayRoles().add(Role.fromString(role));
            }
        }
        if (salary.getPayRoles().isEmpty()) {
            salary.getPayRoles().add(Role.MANAGER);
            salary.getPayRoles().add(Role.EMPLOYEE);
        }
        return salary;
    }
}

