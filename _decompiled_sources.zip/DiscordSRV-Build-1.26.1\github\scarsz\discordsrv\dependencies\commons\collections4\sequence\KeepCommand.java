/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.collections4.sequence;

import github.scarsz.discordsrv.dependencies.commons.collections4.sequence.CommandVisitor;
import github.scarsz.discordsrv.dependencies.commons.collections4.sequence.EditCommand;

public class KeepCommand<T>
extends EditCommand<T> {
    public KeepCommand(T object) {
        super(object);
    }

    @Override
    public void accept(CommandVisitor<T> visitor) {
        visitor.visitKeepCommand(this.getObject());
    }
}

