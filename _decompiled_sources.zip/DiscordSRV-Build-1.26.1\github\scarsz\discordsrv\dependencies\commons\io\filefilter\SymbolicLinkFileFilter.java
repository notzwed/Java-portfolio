/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.io.filefilter;

import github.scarsz.discordsrv.dependencies.commons.io.filefilter.AbstractFileFilter;
import java.io.File;
import java.io.Serializable;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;

public class SymbolicLinkFileFilter
extends AbstractFileFilter
implements Serializable {
    public static final SymbolicLinkFileFilter INSTANCE = new SymbolicLinkFileFilter();
    private static final long serialVersionUID = 1L;

    protected SymbolicLinkFileFilter() {
    }

    @Override
    public boolean accept(File file) {
        return file.isFile();
    }

    public FileVisitResult accept(Path file, BasicFileAttributes attributes) {
        return SymbolicLinkFileFilter.toFileVisitResult((boolean)Files.isSymbolicLink(file), (Path)file);
    }
}

