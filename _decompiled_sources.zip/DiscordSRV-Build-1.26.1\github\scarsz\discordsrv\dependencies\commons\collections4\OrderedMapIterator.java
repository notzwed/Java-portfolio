/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.collections4;

import github.scarsz.discordsrv.dependencies.commons.collections4.MapIterator;
import github.scarsz.discordsrv.dependencies.commons.collections4.OrderedIterator;

public interface OrderedMapIterator<K, V>
extends MapIterator<K, V>,
OrderedIterator<K> {
    @Override
    public boolean hasPrevious();

    @Override
    public K previous();
}

