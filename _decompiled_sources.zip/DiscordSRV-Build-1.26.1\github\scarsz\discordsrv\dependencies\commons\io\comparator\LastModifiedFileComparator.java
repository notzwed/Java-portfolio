/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.io.comparator;

import github.scarsz.discordsrv.dependencies.commons.io.FileUtils;
import github.scarsz.discordsrv.dependencies.commons.io.comparator.AbstractFileComparator;
import github.scarsz.discordsrv.dependencies.commons.io.comparator.ReverseFileComparator;
import java.io.File;
import java.io.Serializable;
import java.util.Comparator;

public class LastModifiedFileComparator
extends AbstractFileComparator
implements Serializable {
    private static final long serialVersionUID = 7372168004395734046L;
    public static final Comparator<File> LASTMODIFIED_COMPARATOR = new LastModifiedFileComparator();
    public static final Comparator<File> LASTMODIFIED_REVERSE = new ReverseFileComparator(LASTMODIFIED_COMPARATOR);

    @Override
    public int compare(File file1, File file2) {
        long result = FileUtils.lastModifiedUnchecked((File)file1) - FileUtils.lastModifiedUnchecked((File)file2);
        if (result < 0L) {
            return -1;
        }
        if (result > 0L) {
            return 1;
        }
        return 0;
    }
}

