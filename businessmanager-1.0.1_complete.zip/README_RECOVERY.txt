﻿Ricostruzione di businessmanager-1.0.1.jar

Contenuto:
- jar_contents/: estrazione completa del JAR originale (classi + risorse)
- src/main/java/: sorgenti Java decompilati da classi
- src/main/resources/: risorse non-.class estratte dal JAR

Nota:
I file in src/main/java sono ottenuti tramite decompilazione e possono differire dal sorgente originale (naming locale, formatting, costrutti sintetici).
