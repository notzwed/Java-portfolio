/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Cancellable
 *  org.bukkit.event.Event
 */
package github.scarsz.discordsrv.api.events;

import github.scarsz.discordsrv.api.events.GameEvent;
import github.scarsz.discordsrv.objects.MessageFormat;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;

public class AchievementMessagePreProcessEvent
extends GameEvent<Event>
implements Cancellable {
    private boolean cancelled;
    private String achievementName;
    private String channel;
    private MessageFormat messageFormat;

    public AchievementMessagePreProcessEvent(String channel, MessageFormat messageFormat, Player player, String achievementName, Event triggeringBukkitEvent) {
        super(player, triggeringBukkitEvent);
        this.channel = channel;
        this.messageFormat = messageFormat;
        this.achievementName = achievementName;
    }

    @Deprecated
    public AchievementMessagePreProcessEvent(String channel, MessageFormat messageFormat, Player player, String achievementName) {
        super(player, null);
        this.channel = channel;
        this.messageFormat = messageFormat;
        this.achievementName = achievementName;
    }

    @Deprecated
    public AchievementMessagePreProcessEvent(String channel, String message, Player player, String achievementName) {
        super(player, null);
        this.channel = channel;
        MessageFormat messageFormat = new MessageFormat();
        messageFormat.setContent(message);
        this.messageFormat = messageFormat;
        this.achievementName = achievementName;
    }

    @Deprecated
    public String getMessage() {
        return this.messageFormat.getContent();
    }

    @Deprecated
    public void setMessage(String message) {
        MessageFormat messageFormat = new MessageFormat();
        messageFormat.setContent(message);
        this.messageFormat = messageFormat;
    }

    public boolean isCancelled() {
        return this.cancelled;
    }

    public void setCancelled(boolean cancelled) {
        this.cancelled = cancelled;
    }

    public String getAchievementName() {
        return this.achievementName;
    }

    public void setAchievementName(String achievementName) {
        this.achievementName = achievementName;
    }

    public String getChannel() {
        return this.channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public MessageFormat getMessageFormat() {
        return this.messageFormat;
    }

    public void setMessageFormat(MessageFormat messageFormat) {
        this.messageFormat = messageFormat;
    }
}

