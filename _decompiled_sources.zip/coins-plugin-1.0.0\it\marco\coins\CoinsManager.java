/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.YamlConfiguration
 */
package it.marco.coins;

import it.marco.coins.CoinsPlugin;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

public class CoinsManager {
    private final CoinsPlugin plugin;
    private final File dataFile;
    private final Map<UUID, Integer> balances = new HashMap<UUID, Integer>();

    public CoinsManager(CoinsPlugin plugin) {
        this.plugin = plugin;
        File dataFolder = plugin.getDataFolder();
        if (!dataFolder.exists()) {
            dataFolder.mkdirs();
        }
        this.dataFile = new File(dataFolder, "data.yml");
    }

    public void load() {
        this.balances.clear();
        if (!this.dataFile.exists()) {
            this.save();
            return;
        }
        YamlConfiguration config = YamlConfiguration.loadConfiguration((File)this.dataFile);
        ConfigurationSection section = config.getConfigurationSection("balances");
        if (section == null) {
            return;
        }
        for (String key : section.getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(key);
                int value = Math.max(0, section.getInt(key));
                this.balances.put(uuid, value);
            }
            catch (IllegalArgumentException ignored) {
                this.plugin.getLogger().warning("UUID non valido in data.yml: " + key);
            }
        }
    }

    public void save() {
        YamlConfiguration config = new YamlConfiguration();
        ConfigurationSection section = config.createSection("balances");
        for (Map.Entry<UUID, Integer> entry : this.balances.entrySet()) {
            section.set(entry.getKey().toString(), (Object)entry.getValue());
        }
        try {
            config.save(this.dataFile);
        }
        catch (IOException e) {
            this.plugin.getLogger().warning("Impossibile salvare data.yml: " + e.getMessage());
        }
    }

    public int getBalance(UUID uuid) {
        return this.balances.getOrDefault(uuid, 0);
    }

    public void setBalance(UUID uuid, int amount) {
        this.balances.put(uuid, Math.max(0, amount));
    }

    public void addBalance(UUID uuid, int amount) {
        if (amount <= 0) {
            return;
        }
        this.setBalance(uuid, this.getBalance(uuid) + amount);
    }

    public void removeBalance(UUID uuid, int amount) {
        if (amount <= 0) {
            return;
        }
        this.setBalance(uuid, this.getBalance(uuid) - amount);
    }
}

