/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.api;

public enum ListenerPriority {
    LOWEST(0),
    LOW(1),
    NORMAL(2),
    HIGH(3),
    HIGHEST(4),
    MONITOR(5);

    private final int slot;

    private ListenerPriority(int slot) {
        this.slot = slot;
    }

    public int getSlot() {
        return this.slot;
    }
}

