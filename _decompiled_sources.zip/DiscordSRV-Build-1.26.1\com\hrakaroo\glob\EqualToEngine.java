/*
 * Decompiled with CFR 0.152.
 */
package com.hrakaroo.glob;

import com.hrakaroo.glob.MatchingEngine;

class EqualToEngine
implements MatchingEngine {
    final char[] lowerCase;
    final char[] upperCase;
    final boolean[] matchOne;
    final int length;

    protected EqualToEngine(char[] lowerCase, char[] upperCase, boolean[] matchOne, int length) {
        this.lowerCase = lowerCase;
        this.upperCase = upperCase;
        this.matchOne = matchOne;
        this.length = length;
    }

    @Override
    public boolean matches(String string) {
        if (string == null) {
            return false;
        }
        if (this.length != string.length()) {
            return false;
        }
        int index = 0;
        while (index != this.length) {
            if (!this.matchOne[index] && string.charAt(index) != this.lowerCase[index] && string.charAt(index) != this.upperCase[index]) {
                return false;
            }
            ++index;
        }
        return true;
    }

    @Override
    public int matchingSizeInBytes() {
        return 4 + this.staticSizeInBytes();
    }

    @Override
    public int staticSizeInBytes() {
        return this.lowerCase.length * 5 + 4;
    }
}

