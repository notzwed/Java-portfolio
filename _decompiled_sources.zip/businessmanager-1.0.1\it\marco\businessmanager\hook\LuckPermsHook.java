/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.luckperms.api.LuckPerms
 *  net.luckperms.api.model.group.Group
 *  net.luckperms.api.model.user.User
 *  net.luckperms.api.query.QueryOptions
 *  org.bukkit.Bukkit
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.plugin.RegisteredServiceProvider
 */
package it.marco.businessmanager.hook;

import it.marco.businessmanager.BusinessManagerPlugin;
import it.marco.businessmanager.model.Role;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.luckperms.api.LuckPerms;
import net.luckperms.api.model.group.Group;
import net.luckperms.api.model.user.User;
import net.luckperms.api.query.QueryOptions;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.plugin.RegisteredServiceProvider;

public class LuckPermsHook {
    private final BusinessManagerPlugin plugin;
    private LuckPerms luckPerms;
    private boolean enabled;
    private boolean usePrimaryGroup;
    private final Map<Role, Set<String>> mapping = new EnumMap<Role, Set<String>>(Role.class);

    public LuckPermsHook(BusinessManagerPlugin plugin) {
        this.plugin = plugin;
        this.reload();
    }

    public void reload() {
        this.enabled = this.plugin.getConfig().getBoolean("luckperms.enabled", true);
        this.usePrimaryGroup = this.plugin.getConfig().getBoolean("luckperms.use-primary-group", true);
        this.mapping.clear();
        for (Role role : Role.values()) {
            this.mapping.put(role, new HashSet());
        }
        ConfigurationSection section = this.plugin.getConfig().getConfigurationSection("luckperms.group-role-mapping");
        if (section != null) {
            for (String key : section.getKeys(false)) {
                Role role;
                role = Role.fromString(key);
                List groups = section.getStringList(key);
                for (String group : groups) {
                    this.mapping.get((Object)role).add(group.toLowerCase());
                }
            }
        }
        this.luckPerms = null;
        if (this.enabled) {
            RegisteredServiceProvider provider = Bukkit.getServicesManager().getRegistration(LuckPerms.class);
            if (provider != null) {
                this.luckPerms = (LuckPerms)provider.getProvider();
                this.plugin.getLogger().info("LuckPerms agganciato.");
            } else {
                this.plugin.getLogger().warning("LuckPerms non trovato.");
            }
        }
    }

    public boolean isEnabled() {
        return this.enabled && this.luckPerms != null;
    }

    public Role resolveRole(UUID uuid) {
        if (!this.isEnabled()) {
            return null;
        }
        User user = this.luckPerms.getUserManager().getUser(uuid);
        if (user == null) {
            return null;
        }
        HashSet<String> groups = new HashSet<String>();
        if (this.usePrimaryGroup) {
            groups.add(user.getPrimaryGroup().toLowerCase());
        } else {
            for (Group group : user.getInheritedGroups(QueryOptions.defaultContextualOptions())) {
                groups.add(group.getName().toLowerCase());
            }
        }
        for (Map.Entry entry : this.mapping.entrySet()) {
            for (String group : (Set)entry.getValue()) {
                if (!groups.contains(group)) continue;
                return (Role)((Object)entry.getKey());
            }
        }
        return null;
    }
}

