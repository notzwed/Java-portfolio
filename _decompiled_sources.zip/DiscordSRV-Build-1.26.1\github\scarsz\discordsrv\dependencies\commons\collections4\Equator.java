/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.collections4;

public interface Equator<T> {
    public boolean equate(T var1, T var2);

    public int hash(T var1);
}

