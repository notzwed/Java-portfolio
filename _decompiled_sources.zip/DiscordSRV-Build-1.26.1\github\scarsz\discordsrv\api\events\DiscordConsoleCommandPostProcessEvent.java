/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.api.events;

import github.scarsz.discordsrv.api.events.DiscordEvent;
import github.scarsz.discordsrv.dependencies.jda.api.events.message.guild.GuildMessageReceivedEvent;

public class DiscordConsoleCommandPostProcessEvent
extends DiscordEvent<GuildMessageReceivedEvent> {
    private boolean sentInConsoleChannel;
    private String command;

    public DiscordConsoleCommandPostProcessEvent(GuildMessageReceivedEvent jdaEvent, String command, boolean sentInConsoleChannel) {
        super(jdaEvent.getJDA(), jdaEvent);
        this.command = command;
        this.sentInConsoleChannel = sentInConsoleChannel;
    }

    public boolean isSentInConsoleChannel() {
        return this.sentInConsoleChannel;
    }

    public String getCommand() {
        return this.command;
    }
}

