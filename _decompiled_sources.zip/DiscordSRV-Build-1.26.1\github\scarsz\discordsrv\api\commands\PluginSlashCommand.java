/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.plugin.Plugin
 */
package github.scarsz.discordsrv.api.commands;

import github.scarsz.discordsrv.api.commands.SlashCommandPriority;
import github.scarsz.discordsrv.dependencies.jda.api.entities.Guild;
import github.scarsz.discordsrv.dependencies.jda.api.interactions.commands.build.CommandData;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import org.bukkit.plugin.Plugin;

public final class PluginSlashCommand {
    private final Plugin plugin;
    private final CommandData commandData;
    private final Set<String> guilds = new HashSet<String>();
    private SlashCommandPriority priority;

    public PluginSlashCommand(Plugin plugin, CommandData commandData) {
        this(plugin, commandData, SlashCommandPriority.NORMAL);
    }

    public PluginSlashCommand(Plugin plugin, CommandData commandData, SlashCommandPriority priority) {
        this(plugin, commandData, priority, (String[])null);
    }

    public PluginSlashCommand(Plugin plugin, CommandData commandData, String ... guildIds) {
        this(plugin, commandData, SlashCommandPriority.NORMAL, guildIds);
    }

    public PluginSlashCommand(Plugin plugin, CommandData commandData, SlashCommandPriority priority, String ... guildIds) {
        this.plugin = plugin;
        this.commandData = commandData;
        this.priority = priority;
        if (guildIds != null) {
            Collections.addAll(this.guilds, guildIds);
        }
    }

    public boolean isApplicable(Guild guild) {
        return this.guilds.isEmpty() || this.guilds.contains(guild.getId());
    }

    public PluginSlashCommand addGuildFilter(Guild guild) {
        return this.addGuildFilter(guild.getId());
    }

    public PluginSlashCommand addGuildFilter(String guildId) {
        this.guilds.add(guildId);
        return this;
    }

    public PluginSlashCommand removeGuildFilter(Guild guild) {
        return this.removeGuildFilter(guild.getId());
    }

    public PluginSlashCommand removeGuildFilter(String guildId) {
        this.guilds.remove(guildId);
        return this;
    }

    public PluginSlashCommand setPriority(SlashCommandPriority priority) {
        this.priority = priority;
        return this;
    }

    public Plugin getPlugin() {
        return this.plugin;
    }

    public CommandData getCommandData() {
        return this.commandData;
    }

    public Set<String> getGuilds() {
        return this.guilds;
    }

    public SlashCommandPriority getPriority() {
        return this.priority;
    }

    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof PluginSlashCommand)) {
            return false;
        }
        PluginSlashCommand other = (PluginSlashCommand)o;
        Plugin this$plugin = this.getPlugin();
        Plugin other$plugin = other.getPlugin();
        if (this$plugin == null ? other$plugin != null : !this$plugin.equals(other$plugin)) {
            return false;
        }
        CommandData this$commandData = this.getCommandData();
        CommandData other$commandData = other.getCommandData();
        if (this$commandData == null ? other$commandData != null : !this$commandData.equals(other$commandData)) {
            return false;
        }
        Set<String> this$guilds = this.getGuilds();
        Set<String> other$guilds = other.getGuilds();
        if (this$guilds == null ? other$guilds != null : !((Object)this$guilds).equals(other$guilds)) {
            return false;
        }
        SlashCommandPriority this$priority = this.getPriority();
        SlashCommandPriority other$priority = other.getPriority();
        return !(this$priority == null ? other$priority != null : !((Object)((Object)this$priority)).equals((Object)other$priority));
    }

    public int hashCode() {
        int PRIME = 59;
        int result = 1;
        Plugin $plugin = this.getPlugin();
        result = result * 59 + ($plugin == null ? 43 : $plugin.hashCode());
        CommandData $commandData = this.getCommandData();
        result = result * 59 + ($commandData == null ? 43 : $commandData.hashCode());
        Set<String> $guilds = this.getGuilds();
        result = result * 59 + ($guilds == null ? 43 : ((Object)$guilds).hashCode());
        SlashCommandPriority $priority = this.getPriority();
        result = result * 59 + ($priority == null ? 43 : ((Object)((Object)$priority)).hashCode());
        return result;
    }

    public String toString() {
        return "PluginSlashCommand(plugin=" + this.getPlugin() + ", commandData=" + this.getCommandData() + ", guilds=" + this.getGuilds() + ", priority=" + (Object)((Object)this.getPriority()) + ")";
    }
}

