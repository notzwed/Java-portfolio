/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.collections4.set;

import github.scarsz.discordsrv.dependencies.commons.collections4.Predicate;
import github.scarsz.discordsrv.dependencies.commons.collections4.collection.PredicatedCollection;
import java.util.Set;

public class PredicatedSet<E>
extends PredicatedCollection<E>
implements Set<E> {
    private static final long serialVersionUID = -684521469108685117L;

    public static <E> PredicatedSet<E> predicatedSet(Set<E> set, Predicate<? super E> predicate) {
        return new PredicatedSet<E>(set, predicate);
    }

    protected PredicatedSet(Set<E> set, Predicate<? super E> predicate) {
        super(set, predicate);
    }

    @Override
    protected Set<E> decorated() {
        return (Set)super.decorated();
    }

    @Override
    public boolean equals(Object object) {
        return object == this || this.decorated().equals(object);
    }

    @Override
    public int hashCode() {
        return this.decorated().hashCode();
    }
}

