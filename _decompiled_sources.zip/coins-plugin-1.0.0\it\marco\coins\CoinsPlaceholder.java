/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  me.clip.placeholderapi.expansion.PlaceholderExpansion
 *  org.bukkit.entity.Player
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package it.marco.coins;

import it.marco.coins.CoinsPlugin;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class CoinsPlaceholder
extends PlaceholderExpansion {
    private final CoinsPlugin plugin;

    public CoinsPlaceholder(CoinsPlugin plugin) {
        this.plugin = plugin;
    }

    @NotNull
    public String getIdentifier() {
        return "coins";
    }

    @NotNull
    public String getAuthor() {
        return "Marco";
    }

    @NotNull
    public String getVersion() {
        return this.plugin.getDescription().getVersion();
    }

    public boolean persist() {
        return true;
    }

    @Nullable
    public String onPlaceholderRequest(Player player, @NotNull String params) {
        if (player == null) {
            return "";
        }
        int balance = this.plugin.getCoinsManager().getBalance(player.getUniqueId());
        if (params.equalsIgnoreCase("balance") || params.equalsIgnoreCase("coins")) {
            return String.valueOf(balance);
        }
        if (params.equalsIgnoreCase("formatted") || params.equalsIgnoreCase("balance_formatted") || params.equalsIgnoreCase("coins_formatted")) {
            return this.plugin.formatCoins(balance);
        }
        return null;
    }
}

