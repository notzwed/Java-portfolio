/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.alexh.weak;

import github.scarsz.discordsrv.dependencies.alexh.LiteJoiner;
import github.scarsz.discordsrv.dependencies.alexh.weak.AbstractAbsence;
import github.scarsz.discordsrv.dependencies.alexh.weak.Describer;
import github.scarsz.discordsrv.dependencies.alexh.weak.DescriptionDeferringAbsence;
import github.scarsz.discordsrv.dependencies.alexh.weak.Dynamic;
import github.scarsz.discordsrv.dependencies.alexh.weak.DynamicChildLogic;
import github.scarsz.discordsrv.dependencies.alexh.weak.IssueDescribingChild;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.NoSuchElementException;

public abstract class ChildAbsence<Parent extends Dynamic>
extends AbstractAbsence<Parent>
implements IssueDescribingChild {
    protected ChildAbsence(Parent parent, Object key) {
        super(parent, key);
    }

    protected abstract String describeIssue(LinkedList<Object> var1, LinkedList<Object> var2);

    @Override
    public final String describeIssue(List<Object> childKeys) {
        LinkedList<Object> keyChainUntilSelf = DynamicChildLogic.using(this).getAscendingKeyChainWithRoot();
        keyChainUntilSelf.removeLast();
        LinkedList<Object> fullKeyChain = new LinkedList<Object>(keyChainUntilSelf);
        fullKeyChain.addLast("*" + this.key + "*");
        fullKeyChain.addAll(childKeys);
        return this.describeIssue(fullKeyChain, keyChainUntilSelf);
    }

    @Override
    public Dynamic get(Object key) {
        return new DescriptionDeferringAbsence(this, key);
    }

    @Override
    public Object asObject() {
        throw new NoSuchElementException(this.describeIssue(Collections.emptyList()));
    }

    public static class Missing<P extends Dynamic & Describer>
    extends ChildAbsence<P> {
        public Missing(P parent, Object key) {
            super(parent, key);
        }

        @Override
        protected String describeIssue(LinkedList<Object> ascendingMarkedKeyChain, LinkedList<Object> ascendingKeyChainBeforeSelf) {
            return String.format("'%s' key is missing in path %s, from %s: %s", this.key, LiteJoiner.on("->").join(ascendingMarkedKeyChain), LiteJoiner.on("->").join(ascendingKeyChainBeforeSelf), ((Describer)((Object)this.parent)).describe());
        }
    }

    public static class Null
    extends ChildAbsence<Dynamic> {
        public Null(Dynamic parent, Object key) {
            super(parent, key);
        }

        @Override
        protected String describeIssue(LinkedList<Object> ascendingMarkedKeyChain, LinkedList<Object> ascendingKeyChainBeforeSelf) {
            return String.format("null '%s' premature end of path %s", this.key, LiteJoiner.on("->").join(ascendingMarkedKeyChain));
        }
    }
}

