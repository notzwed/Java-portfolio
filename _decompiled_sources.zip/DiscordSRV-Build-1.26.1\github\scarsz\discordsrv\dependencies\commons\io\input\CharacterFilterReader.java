/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.io.input;

import github.scarsz.discordsrv.dependencies.commons.io.input.AbstractCharacterFilterReader;
import java.io.Reader;
import java.util.function.IntPredicate;

public class CharacterFilterReader
extends AbstractCharacterFilterReader {
    public CharacterFilterReader(Reader reader, int skip) {
        super(reader, c -> c == skip);
    }

    public CharacterFilterReader(Reader reader, IntPredicate skip) {
        super(reader, skip);
    }
}

