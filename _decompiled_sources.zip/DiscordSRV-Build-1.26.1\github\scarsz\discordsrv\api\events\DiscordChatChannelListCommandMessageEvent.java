/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.api.events;

import github.scarsz.discordsrv.api.events.Event;
import github.scarsz.discordsrv.dependencies.jda.api.entities.Guild;
import github.scarsz.discordsrv.dependencies.jda.api.entities.TextChannel;
import github.scarsz.discordsrv.dependencies.jda.api.events.message.guild.GuildMessageReceivedEvent;

public class DiscordChatChannelListCommandMessageEvent
extends Event {
    private Result result;
    private final TextChannel channel;
    private final Guild guild;
    private final String message;
    private final GuildMessageReceivedEvent triggeringJDAEvent;
    private String playerListMessage;
    private int expiration;

    public DiscordChatChannelListCommandMessageEvent(TextChannel channel, Guild guild, String message, GuildMessageReceivedEvent triggeringJDAEvent, String playerListMessage, int expiration, Result result) {
        this.channel = channel;
        this.guild = guild;
        this.message = message;
        this.triggeringJDAEvent = triggeringJDAEvent;
        this.playerListMessage = playerListMessage;
        this.expiration = expiration;
        this.result = result;
    }

    public Result getResult() {
        return this.result;
    }

    public void setResult(Result result) {
        this.result = result;
    }

    public TextChannel getChannel() {
        return this.channel;
    }

    public Guild getGuild() {
        return this.guild;
    }

    public String getMessage() {
        return this.message;
    }

    public GuildMessageReceivedEvent getTriggeringJDAEvent() {
        return this.triggeringJDAEvent;
    }

    public String getPlayerListMessage() {
        return this.playerListMessage;
    }

    public void setPlayerListMessage(String playerListMessage) {
        this.playerListMessage = playerListMessage;
    }

    public int getExpiration() {
        return this.expiration;
    }

    public void setExpiration(int expiration) {
        this.expiration = expiration;
    }

    public static enum Result {
        SEND_RESPONSE,
        NO_ACTION,
        TREAT_AS_REGULAR_MESSAGE;

    }
}

