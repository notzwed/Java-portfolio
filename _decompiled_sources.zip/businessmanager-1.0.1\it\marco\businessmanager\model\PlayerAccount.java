/*
 * Decompiled with CFR 0.152.
 */
package it.marco.businessmanager.model;

public class PlayerAccount {
    private double balance;

    public double getBalance() {
        return this.balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
}

