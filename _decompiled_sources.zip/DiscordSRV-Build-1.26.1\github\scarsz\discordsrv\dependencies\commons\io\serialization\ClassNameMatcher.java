/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.io.serialization;

public interface ClassNameMatcher {
    public boolean matches(String var1);
}

