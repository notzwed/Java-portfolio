/*
 * Decompiled with CFR 0.152.
 */
package com.hrakaroo.glob;

import com.hrakaroo.glob.MatchingEngine;

class EmptyOnlyEngine
implements MatchingEngine {
    static final EmptyOnlyEngine EMPTY_ONLY_ENGINE = new EmptyOnlyEngine();

    private EmptyOnlyEngine() {
    }

    @Override
    public boolean matches(String string) {
        return string != null && string.isEmpty();
    }

    @Override
    public int matchingSizeInBytes() {
        return 0;
    }

    @Override
    public int staticSizeInBytes() {
        return 0;
    }
}

