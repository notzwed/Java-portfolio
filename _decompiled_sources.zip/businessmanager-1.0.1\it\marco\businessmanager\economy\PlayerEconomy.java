/*
 * Decompiled with CFR 0.152.
 */
package it.marco.businessmanager.economy;

import java.util.UUID;

public interface PlayerEconomy {
    public double getBalance(UUID var1);

    public boolean withdraw(UUID var1, double var2);

    public void deposit(UUID var1, double var2);
}

