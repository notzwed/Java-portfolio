/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.io.file;

import github.scarsz.discordsrv.dependencies.commons.io.file.PathVisitor;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;

public abstract class SimplePathVisitor
extends SimpleFileVisitor<Path>
implements PathVisitor {
    protected SimplePathVisitor() {
    }
}

