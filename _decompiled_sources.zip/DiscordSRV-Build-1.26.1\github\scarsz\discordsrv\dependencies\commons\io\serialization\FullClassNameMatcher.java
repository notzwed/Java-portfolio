/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.io.serialization;

import github.scarsz.discordsrv.dependencies.commons.io.serialization.ClassNameMatcher;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

final class FullClassNameMatcher
implements ClassNameMatcher {
    private final Set<String> classesSet;

    public FullClassNameMatcher(String ... classes) {
        this.classesSet = Collections.unmodifiableSet(new HashSet<String>(Arrays.asList(classes)));
    }

    @Override
    public boolean matches(String className) {
        return this.classesSet.contains(className);
    }
}

