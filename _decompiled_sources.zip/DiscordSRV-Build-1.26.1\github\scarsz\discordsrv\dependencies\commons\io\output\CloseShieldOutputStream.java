/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.io.output;

import github.scarsz.discordsrv.dependencies.commons.io.output.ClosedOutputStream;
import github.scarsz.discordsrv.dependencies.commons.io.output.ProxyOutputStream;
import java.io.OutputStream;

public class CloseShieldOutputStream
extends ProxyOutputStream {
    public static CloseShieldOutputStream wrap(OutputStream outputStream) {
        return new CloseShieldOutputStream(outputStream);
    }

    @Deprecated
    public CloseShieldOutputStream(OutputStream outputStream) {
        super(outputStream);
    }

    @Override
    public void close() {
        this.out = ClosedOutputStream.CLOSED_OUTPUT_STREAM;
    }
}

