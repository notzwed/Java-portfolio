/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.io.monitor;

import github.scarsz.discordsrv.dependencies.commons.io.monitor.FileAlterationObserver;
import java.io.File;

public interface FileAlterationListener {
    public void onStart(FileAlterationObserver var1);

    public void onDirectoryCreate(File var1);

    public void onDirectoryChange(File var1);

    public void onDirectoryDelete(File var1);

    public void onFileCreate(File var1);

    public void onFileChange(File var1);

    public void onFileDelete(File var1);

    public void onStop(FileAlterationObserver var1);
}

