/*
 * Decompiled with CFR 0.152.
 */
package it.marco.businessmanager.model;

public class Investment {
    private String id;
    private String optionId;
    private double principal;
    private long startEpoch;
    private int durationMinutes;
    private double returnMultiplier;
    private boolean claimed;

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getOptionId() {
        return this.optionId;
    }

    public void setOptionId(String optionId) {
        this.optionId = optionId;
    }

    public double getPrincipal() {
        return this.principal;
    }

    public void setPrincipal(double principal) {
        this.principal = principal;
    }

    public long getStartEpoch() {
        return this.startEpoch;
    }

    public void setStartEpoch(long startEpoch) {
        this.startEpoch = startEpoch;
    }

    public int getDurationMinutes() {
        return this.durationMinutes;
    }

    public void setDurationMinutes(int durationMinutes) {
        this.durationMinutes = durationMinutes;
    }

    public double getReturnMultiplier() {
        return this.returnMultiplier;
    }

    public void setReturnMultiplier(double returnMultiplier) {
        this.returnMultiplier = returnMultiplier;
    }

    public boolean isClaimed() {
        return this.claimed;
    }

    public void setClaimed(boolean claimed) {
        this.claimed = claimed;
    }

    public boolean isMatured(long now) {
        long end = this.startEpoch + (long)this.durationMinutes * 60L * 1000L;
        return now >= end;
    }

    public double getReturnAmount() {
        return this.principal * this.returnMultiplier;
    }
}

