/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.collections4;

import github.scarsz.discordsrv.dependencies.commons.collections4.Get;
import github.scarsz.discordsrv.dependencies.commons.collections4.MapIterator;

public interface IterableGet<K, V>
extends Get<K, V> {
    public MapIterator<K, V> mapIterator();
}

