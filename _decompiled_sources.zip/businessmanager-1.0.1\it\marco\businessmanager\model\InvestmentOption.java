/*
 * Decompiled with CFR 0.152.
 */
package it.marco.businessmanager.model;

public class InvestmentOption {
    private final String id;
    private final String name;
    private final double min;
    private final double max;
    private final int durationMinutes;
    private final double returnMultiplier;

    public InvestmentOption(String id, String name, double min, double max, int durationMinutes, double returnMultiplier) {
        this.id = id;
        this.name = name;
        this.min = min;
        this.max = max;
        this.durationMinutes = durationMinutes;
        this.returnMultiplier = returnMultiplier;
    }

    public String getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public double getMin() {
        return this.min;
    }

    public double getMax() {
        return this.max;
    }

    public int getDurationMinutes() {
        return this.durationMinutes;
    }

    public double getReturnMultiplier() {
        return this.returnMultiplier;
    }
}

