/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.collections4;

public interface Transformer<I, O> {
    public O transform(I var1);
}

