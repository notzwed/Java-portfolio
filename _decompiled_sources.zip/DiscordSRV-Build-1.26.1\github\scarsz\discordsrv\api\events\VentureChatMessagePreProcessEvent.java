/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  mineverse.Aust1n46.chat.api.events.VentureChatEvent
 *  org.bukkit.event.Cancellable
 */
package github.scarsz.discordsrv.api.events;

import github.scarsz.discordsrv.api.events.VentureChatMessageEvent;
import github.scarsz.discordsrv.dependencies.kyori.adventure.text.Component;
import github.scarsz.discordsrv.util.MessageUtil;
import mineverse.Aust1n46.chat.api.events.VentureChatEvent;
import org.bukkit.event.Cancellable;

public class VentureChatMessagePreProcessEvent
extends VentureChatMessageEvent
implements Cancellable {
    private boolean cancelled;
    private String channel;
    private Component messageComponent;

    public VentureChatMessagePreProcessEvent(String channel, Component message, VentureChatEvent ventureChatEvent) {
        super(ventureChatEvent);
        this.channel = channel;
        this.messageComponent = message;
    }

    @Deprecated
    public VentureChatMessagePreProcessEvent(String channel, String message, VentureChatEvent ventureChatEvent) {
        this(channel, MessageUtil.toComponent(message, true), ventureChatEvent);
    }

    @Deprecated
    public String getMessage() {
        return MessageUtil.toLegacy(this.messageComponent);
    }

    @Deprecated
    public void setMessage(String legacy) {
        this.messageComponent = MessageUtil.toComponent(legacy, true);
    }

    public boolean isCancelled() {
        return this.cancelled;
    }

    public void setCancelled(boolean cancelled) {
        this.cancelled = cancelled;
    }

    public String getChannel() {
        return this.channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public Component getMessageComponent() {
        return this.messageComponent;
    }

    public void setMessageComponent(Component messageComponent) {
        this.messageComponent = messageComponent;
    }
}

