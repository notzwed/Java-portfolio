/*
 * Decompiled with CFR 0.152.
 */
package it.marco.businessmanager.model;

public enum Role {
    DIRECTOR,
    MANAGER,
    EMPLOYEE;


    public static Role fromString(String value) {
        if (value == null) {
            return EMPLOYEE;
        }
        String v = value.trim().toUpperCase();
        for (Role role : Role.values()) {
            if (!role.name().equalsIgnoreCase(v)) continue;
            return role;
        }
        return EMPLOYEE;
    }
}

