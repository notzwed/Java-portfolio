/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.OfflinePlayer
 */
package github.scarsz.discordsrv.api.events;

import github.scarsz.discordsrv.api.events.Event;
import github.scarsz.discordsrv.dependencies.jda.api.entities.User;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;

public class AccountLinkedEvent
extends Event {
    private final OfflinePlayer player;
    private final User user;

    public AccountLinkedEvent(User user, UUID playerUuid) {
        this.player = Bukkit.getOfflinePlayer((UUID)playerUuid);
        this.user = user;
    }

    public OfflinePlayer getPlayer() {
        return this.player;
    }

    public User getUser() {
        return this.user;
    }
}

