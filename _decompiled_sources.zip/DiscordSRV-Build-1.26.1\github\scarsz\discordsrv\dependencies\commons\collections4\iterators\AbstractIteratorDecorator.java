/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.collections4.iterators;

import github.scarsz.discordsrv.dependencies.commons.collections4.iterators.AbstractUntypedIteratorDecorator;
import java.util.Iterator;

public abstract class AbstractIteratorDecorator<E>
extends AbstractUntypedIteratorDecorator<E, E> {
    protected AbstractIteratorDecorator(Iterator<E> iterator) {
        super(iterator);
    }

    @Override
    public E next() {
        return (E)this.getIterator().next();
    }
}

