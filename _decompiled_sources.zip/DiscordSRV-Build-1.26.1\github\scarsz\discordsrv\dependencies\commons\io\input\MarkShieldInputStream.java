/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.io.input;

import github.scarsz.discordsrv.dependencies.commons.io.input.ProxyInputStream;
import github.scarsz.discordsrv.dependencies.commons.io.input.UnsupportedOperationExceptions;
import java.io.IOException;
import java.io.InputStream;

public class MarkShieldInputStream
extends ProxyInputStream {
    public MarkShieldInputStream(InputStream in) {
        super(in);
    }

    @Override
    public void mark(int readlimit) {
    }

    @Override
    public boolean markSupported() {
        return false;
    }

    @Override
    public void reset() throws IOException {
        throw UnsupportedOperationExceptions.reset();
    }
}

