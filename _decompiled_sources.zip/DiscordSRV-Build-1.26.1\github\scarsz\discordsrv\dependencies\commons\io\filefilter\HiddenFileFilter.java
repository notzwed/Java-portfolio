/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.io.filefilter;

import github.scarsz.discordsrv.dependencies.commons.io.filefilter.AbstractFileFilter;
import github.scarsz.discordsrv.dependencies.commons.io.filefilter.IOFileFilter;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;

public class HiddenFileFilter
extends AbstractFileFilter
implements Serializable {
    public static final IOFileFilter HIDDEN = new HiddenFileFilter();
    private static final long serialVersionUID = 8930842316112759062L;
    public static final IOFileFilter VISIBLE = HIDDEN.negate();

    protected HiddenFileFilter() {
    }

    @Override
    public boolean accept(File file) {
        return file.isHidden();
    }

    public FileVisitResult accept(Path file, BasicFileAttributes attributes) {
        try {
            return HiddenFileFilter.toFileVisitResult((boolean)Files.isHidden(file), (Path)file);
        }
        catch (IOException e) {
            return this.handle(e);
        }
    }
}

