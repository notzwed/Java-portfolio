/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.event.Cancellable
 */
package github.scarsz.discordsrv.api.events;

import github.scarsz.discordsrv.api.events.Event;
import org.bukkit.event.Cancellable;

public class WatchdogMessagePreProcessEvent
extends Event
implements Cancellable {
    private boolean cancelled;
    private String channel;
    private String message;
    private int count;

    public WatchdogMessagePreProcessEvent(String channel, String message, int count, boolean cancelled) {
        this.channel = channel;
        this.count = count;
        this.message = message;
        this.setCancelled(cancelled);
    }

    public boolean isCancelled() {
        return this.cancelled;
    }

    public void setCancelled(boolean cancelled) {
        this.cancelled = cancelled;
    }

    public String getChannel() {
        return this.channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public String getMessage() {
        return this.message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getCount() {
        return this.count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}

