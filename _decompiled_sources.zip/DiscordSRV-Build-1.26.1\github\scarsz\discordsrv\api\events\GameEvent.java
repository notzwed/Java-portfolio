/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Event
 */
package github.scarsz.discordsrv.api.events;

import github.scarsz.discordsrv.api.events.Event;
import org.bukkit.entity.Player;

abstract class GameEvent<T extends org.bukkit.event.Event>
extends Event {
    private final Player player;
    private final T triggeringBukkitEvent;

    GameEvent(Player player, T triggeringBukkitEvent) {
        this.player = player;
        this.triggeringBukkitEvent = triggeringBukkitEvent;
    }

    public Player getPlayer() {
        return this.player;
    }

    public T getTriggeringBukkitEvent() {
        return this.triggeringBukkitEvent;
    }
}

