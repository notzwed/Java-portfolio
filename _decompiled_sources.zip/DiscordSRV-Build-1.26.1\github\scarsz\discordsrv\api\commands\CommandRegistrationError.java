/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.api.commands;

import github.scarsz.discordsrv.dependencies.jda.api.entities.Guild;

public final class CommandRegistrationError {
    private final Guild guild;
    private final Throwable exception;

    public CommandRegistrationError(Guild guild, Throwable exception) {
        this.guild = guild;
        this.exception = exception;
    }

    public Guild getGuild() {
        return this.guild;
    }

    public Throwable getException() {
        return this.exception;
    }

    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof CommandRegistrationError)) {
            return false;
        }
        CommandRegistrationError other = (CommandRegistrationError)o;
        Guild this$guild = this.getGuild();
        Guild other$guild = other.getGuild();
        if (this$guild == null ? other$guild != null : !this$guild.equals(other$guild)) {
            return false;
        }
        Throwable this$exception = this.getException();
        Throwable other$exception = other.getException();
        return !(this$exception == null ? other$exception != null : !this$exception.equals(other$exception));
    }

    public int hashCode() {
        int PRIME = 59;
        int result = 1;
        Guild $guild = this.getGuild();
        result = result * 59 + ($guild == null ? 43 : $guild.hashCode());
        Throwable $exception = this.getException();
        result = result * 59 + ($exception == null ? 43 : $exception.hashCode());
        return result;
    }

    public String toString() {
        return "CommandRegistrationError(guild=" + this.getGuild() + ", exception=" + this.getException() + ")";
    }
}

