/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.collections4.map;

import github.scarsz.discordsrv.dependencies.commons.collections4.IterableMap;
import github.scarsz.discordsrv.dependencies.commons.collections4.MapIterator;
import github.scarsz.discordsrv.dependencies.commons.collections4.map.EntrySetToMapIteratorAdapter;

public abstract class AbstractIterableMap<K, V>
implements IterableMap<K, V> {
    @Override
    public MapIterator<K, V> mapIterator() {
        return new EntrySetToMapIteratorAdapter(this.entrySet());
    }
}

