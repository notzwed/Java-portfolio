/*
 * Decompiled with CFR 0.152.
 */
package it.marco.businessmanager.economy;

import it.marco.businessmanager.data.DataStore;
import it.marco.businessmanager.economy.PlayerEconomy;
import it.marco.businessmanager.model.PlayerAccount;
import java.util.UUID;

public class InternalEconomy
implements PlayerEconomy {
    private final DataStore dataStore;
    private final boolean allowNegative;

    public InternalEconomy(DataStore dataStore, boolean allowNegative) {
        this.dataStore = dataStore;
        this.allowNegative = allowNegative;
    }

    @Override
    public double getBalance(UUID uuid) {
        return this.dataStore.getOrCreateAccount(uuid).getBalance();
    }

    @Override
    public boolean withdraw(UUID uuid, double amount) {
        PlayerAccount account = this.dataStore.getOrCreateAccount(uuid);
        double balance = account.getBalance();
        if (!this.allowNegative && balance < amount) {
            return false;
        }
        account.setBalance(balance - amount);
        return true;
    }

    @Override
    public void deposit(UUID uuid, double amount) {
        PlayerAccount account = this.dataStore.getOrCreateAccount(uuid);
        account.setBalance(account.getBalance() + amount);
    }
}

