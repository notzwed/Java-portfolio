/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.io.filefilter;

import github.scarsz.discordsrv.dependencies.commons.io.filefilter.IOFileFilter;
import java.util.List;

public interface ConditionalFileFilter {
    public void addFileFilter(IOFileFilter var1);

    public List<IOFileFilter> getFileFilters();

    public boolean removeFileFilter(IOFileFilter var1);

    public void setFileFilters(List<IOFileFilter> var1);
}

