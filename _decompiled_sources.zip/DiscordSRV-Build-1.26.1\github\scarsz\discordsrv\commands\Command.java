/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.commands;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(value=RetentionPolicy.RUNTIME)
@Target(value={ElementType.METHOD})
public @interface Command {
    public String[] commandNames();

    public String helpMessage();

    public String permission();

    public String usageExample() default "";
}

