/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.entity.Player
 */
package it.marco.businessmanager.command;

import it.marco.businessmanager.BusinessManagerPlugin;
import it.marco.businessmanager.data.DataStore;
import it.marco.businessmanager.economy.EconomyService;
import it.marco.businessmanager.hook.LuckPermsHook;
import it.marco.businessmanager.model.Company;
import it.marco.businessmanager.model.Investment;
import it.marco.businessmanager.model.InvestmentOption;
import it.marco.businessmanager.model.Role;
import it.marco.businessmanager.model.SalaryConfig;
import it.marco.businessmanager.model.Stock;
import it.marco.businessmanager.service.SalaryScheduler;
import it.marco.businessmanager.util.CommandUtil;
import it.marco.businessmanager.util.MessageManager;
import it.marco.businessmanager.util.TextUtil;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public class BmCommand
implements CommandExecutor,
TabCompleter {
    private final BusinessManagerPlugin plugin;
    private final DataStore dataStore;
    private final MessageManager messages;
    private final EconomyService economy;
    private final LuckPermsHook luckPerms;
    private final SalaryScheduler salaryScheduler;

    public BmCommand(BusinessManagerPlugin businessManagerPlugin) {
        this.plugin = businessManagerPlugin;
        this.dataStore = businessManagerPlugin.getDataStore();
        this.messages = businessManagerPlugin.getMessages();
        this.economy = businessManagerPlugin.getEconomyService();
        this.luckPerms = businessManagerPlugin.getLuckPermsHook();
        this.salaryScheduler = businessManagerPlugin.getSalaryScheduler();
    }

    public boolean onCommand(CommandSender commandSender, Command command, String string, String[] stringArray) {
        if (stringArray.length == 0) {
            if (this.canUseBm(commandSender)) {
                this.sendHelp(commandSender);
                return true;
            }
            if (this.canUseSpiega(commandSender)) {
                return this.handleSpiega(commandSender);
            }
            commandSender.sendMessage(this.messages.get("no-permission"));
            return true;
        }
        String string2 = stringArray[0].toLowerCase(Locale.ROOT);
        if (string2.equals("spiega")) {
            if (!this.canUseSpiega(commandSender)) {
                commandSender.sendMessage(this.messages.get("no-permission"));
                return true;
            }
            return this.handleSpiega(commandSender);
        }
        if (!this.canUseBm(commandSender)) {
            commandSender.sendMessage(this.messages.get("no-permission"));
            return true;
        }
        switch (string2) {
            case "help": {
                this.sendHelp(commandSender);
                return true;
            }
            case "reload": {
                if (!this.isStaff(commandSender)) {
                    commandSender.sendMessage(this.messages.get("no-permission"));
                    return true;
                }
                this.plugin.reloadAll();
                commandSender.sendMessage(this.messages.get("reload-done"));
                return true;
            }
            case "company": {
                return this.handleCompany(commandSender, stringArray);
            }
            case "invest": {
                return this.handleInvest(commandSender, stringArray);
            }
            case "transfer": {
                return this.handleTransfer(commandSender, stringArray);
            }
        }
        commandSender.sendMessage(this.messages.get("unknown-command"));
        return true;
    }

    private boolean handleWallet(CommandSender commandSender, String[] stringArray) {
        if (!(commandSender instanceof Player)) {
            commandSender.sendMessage(this.messages.get("player-only"));
            return true;
        }
        if (!this.economy.isUsingInternal()) {
            commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "Wallet interno disattivato (Vault attivo).");
            return true;
        }
        Player player = (Player)commandSender;
        commandSender.sendMessage(this.messages.format("wallet-balance", Map.of("balance", this.economy.format(this.economy.getPlayerBalance(player.getUniqueId())))));
        return true;
    }

    private boolean handleCompany(CommandSender commandSender, String[] stringArray) {
        String string;
        if (stringArray.length < 2) {
            this.sendHelp(commandSender);
            return true;
        }
        switch (string = stringArray[1].toLowerCase(Locale.ROOT)) {
            case "create": {
                return this.companyCreate(commandSender, stringArray);
            }
            case "info": {
                return this.companyInfo(commandSender, stringArray);
            }
            case "list": {
                return this.companyList(commandSender);
            }
            case "deposit": {
                return this.companyDeposit(commandSender, stringArray);
            }
            case "withdraw": {
                return this.companyWithdraw(commandSender, stringArray);
            }
            case "add": {
                return this.companyAdd(commandSender, stringArray);
            }
            case "remove": {
                return this.companyRemove(commandSender, stringArray);
            }
            case "role": {
                return this.companyRole(commandSender, stringArray);
            }
            case "setdirector": {
                return this.companySetDirector(commandSender, stringArray);
            }
            case "salary": {
                return this.companySalary(commandSender, stringArray);
            }
            case "syncroles": {
                return this.companySyncRoles(commandSender, stringArray);
            }
        }
        commandSender.sendMessage(this.messages.get("unknown-command"));
        return true;
    }

    private boolean companyCreate(CommandSender commandSender, String[] stringArray) {
        if (!(commandSender instanceof Player)) {
            commandSender.sendMessage(this.messages.get("player-only"));
            return true;
        }
        if (!this.isStaff(commandSender)) {
            commandSender.sendMessage(this.messages.get("no-permission"));
            return true;
        }
        if (stringArray.length < 4) {
            commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "Uso: /bm company create <id> <nome>");
            return true;
        }
        Player player = (Player)commandSender;
        String string = stringArray[2].toLowerCase(Locale.ROOT);
        if (!this.dataStore.isValidCompanyId(string)) {
            commandSender.sendMessage(this.messages.get("invalid-id"));
            return true;
        }
        if (this.dataStore.getCompany(string) != null) {
            commandSender.sendMessage(this.messages.get("company-exists"));
            return true;
        }
        int n = this.plugin.getConfig().getInt("company.max-per-player", 1);
        if (n > 0 && this.dataStore.getCompanyCountForDirector(player.getUniqueId()) >= n) {
            commandSender.sendMessage(String.valueOf(ChatColor.RED) + "Hai raggiunto il limite di aziende: " + n);
            return true;
        }
        Company company = new Company();
        company.setId(string);
        company.setName(TextUtil.join(stringArray, 3));
        company.setDirector(player.getUniqueId());
        company.setBalance(this.plugin.getConfig().getDouble("company.starting-balance", 0.0));
        SalaryConfig salaryConfig = new SalaryConfig();
        salaryConfig.setAmount(this.plugin.getConfig().getDouble("salary.default-amount", 100.0));
        salaryConfig.setIntervalMinutes(this.plugin.getConfig().getInt("salary.default-interval-minutes", 60));
        salaryConfig.setEnabled(false);
        salaryConfig.setLastPaidEpoch(0L);
        for (String string2 : this.plugin.getConfig().getStringList("salary.default-pay-roles")) {
            salaryConfig.getPayRoles().add(Role.fromString(string2));
        }
        if (salaryConfig.getPayRoles().isEmpty()) {
            salaryConfig.getPayRoles().add(Role.MANAGER);
            salaryConfig.getPayRoles().add(Role.EMPLOYEE);
        }
        company.setSalaryConfig(salaryConfig);
        this.dataStore.addCompany(company);
        this.dataStore.save();
        commandSender.sendMessage(this.messages.format("company-created", Map.of("company", company.getName())));
        return true;
    }

    private boolean companyInfo(CommandSender commandSender, String[] stringArray) {
        if (stringArray.length < 3) {
            commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "Uso: /bm company info <id>");
            return true;
        }
        Company company = this.dataStore.getCompany(stringArray[2]);
        if (company == null) {
            commandSender.sendMessage(this.messages.get("company-not-found"));
            return true;
        }
        commandSender.sendMessage(this.messages.format("company-info-header", Map.of("company", company.getName())));
        OfflinePlayer offlinePlayer = company.getDirector() != null ? Bukkit.getOfflinePlayer((UUID)company.getDirector()) : null;
        String string = offlinePlayer != null ? offlinePlayer.getName() : "-";
        commandSender.sendMessage(this.messages.format("company-info-line", Map.of("director", string != null ? string : "-", "balance", this.economy.format(company.getBalance()))));
        commandSender.sendMessage(String.valueOf(ChatColor.GRAY) + "Membri: " + company.getMembers().size());
        commandSender.sendMessage(String.valueOf(ChatColor.GRAY) + "Azioni: " + company.getStocks().size());
        commandSender.sendMessage(String.valueOf(ChatColor.GRAY) + "Investimenti: " + company.getInvestments().size());
        return true;
    }

    private boolean companyList(CommandSender commandSender) {
        commandSender.sendMessage(String.valueOf(ChatColor.GOLD) + "Aziende registrate: " + this.dataStore.getCompanies().size());
        for (Company company : this.dataStore.getCompanies()) {
            commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "- " + company.getId() + String.valueOf(ChatColor.GRAY) + " (" + company.getName() + ")");
        }
        return true;
    }

    private boolean companyDeposit(CommandSender commandSender, String[] stringArray) {
        if (!(commandSender instanceof Player)) {
            commandSender.sendMessage(this.messages.get("player-only"));
            return true;
        }
        if (stringArray.length < 4) {
            commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "Uso: /bm company deposit <id> <importo>");
            return true;
        }
        Player player = (Player)commandSender;
        Company company = this.dataStore.getCompany(stringArray[2]);
        if (company == null) {
            commandSender.sendMessage(this.messages.get("company-not-found"));
            return true;
        }
        if (!this.canManageCompany(player, company, Role.MANAGER)) {
            commandSender.sendMessage(this.messages.get("no-permission"));
            return true;
        }
        Double d = CommandUtil.parseDouble(stringArray[3]);
        if (d == null || d <= 0.0) {
            commandSender.sendMessage(this.messages.get("invalid-number"));
            return true;
        }
        if (!this.economy.withdrawPlayer(player.getUniqueId(), d)) {
            commandSender.sendMessage(this.messages.get("player-insufficient-funds"));
            return true;
        }
        company.setBalance(company.getBalance() + d);
        commandSender.sendMessage(this.messages.format("company-deposited", Map.of("company", company.getName(), "amount", this.economy.format(d))));
        return true;
    }

    private boolean companyWithdraw(CommandSender commandSender, String[] stringArray) {
        if (!(commandSender instanceof Player)) {
            commandSender.sendMessage(this.messages.get("player-only"));
            return true;
        }
        if (stringArray.length < 4) {
            commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "Uso: /bm company withdraw <id> <importo>");
            return true;
        }
        Player player = (Player)commandSender;
        Company company = this.dataStore.getCompany(stringArray[2]);
        if (company == null) {
            commandSender.sendMessage(this.messages.get("company-not-found"));
            return true;
        }
        if (!this.isStaff(commandSender)) {
            commandSender.sendMessage(this.messages.get("no-permission"));
            return true;
        }
        Double d = CommandUtil.parseDouble(stringArray[3]);
        if (d == null || d <= 0.0) {
            commandSender.sendMessage(this.messages.get("invalid-number"));
            return true;
        }
        if (company.getBalance() < d) {
            commandSender.sendMessage(this.messages.get("company-insufficient-funds"));
            return true;
        }
        company.setBalance(company.getBalance() - d);
        this.economy.depositPlayer(player.getUniqueId(), d);
        commandSender.sendMessage(this.messages.format("company-withdrawn", Map.of("company", company.getName(), "amount", this.economy.format(d))));
        return true;
    }

    private boolean companyAdd(CommandSender commandSender, String[] stringArray) {
        Role role;
        if (!(commandSender instanceof Player)) {
            commandSender.sendMessage(this.messages.get("player-only"));
            return true;
        }
        if (stringArray.length < 4) {
            commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "Uso: /bm company add <id> <player> [ruolo]");
            return true;
        }
        Player player = (Player)commandSender;
        Company company = this.dataStore.getCompany(stringArray[2]);
        if (company == null) {
            commandSender.sendMessage(this.messages.get("company-not-found"));
            return true;
        }
        if (!this.canManageCompany(player, company, Role.MANAGER)) {
            commandSender.sendMessage(this.messages.get("no-permission"));
            return true;
        }
        OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer((String)stringArray[3]);
        if (offlinePlayer == null || offlinePlayer.getUniqueId() == null) {
            commandSender.sendMessage(String.valueOf(ChatColor.RED) + "Giocatore non trovato.");
            return true;
        }
        Role role2 = stringArray.length >= 5 ? Role.fromString(stringArray[4]) : Role.EMPLOYEE;
        Role role3 = role2;
        if (this.luckPerms.isEnabled() && (role = this.luckPerms.resolveRole(offlinePlayer.getUniqueId())) != null) {
            role2 = role;
        }
        company.addMember(offlinePlayer.getUniqueId(), role2);
        commandSender.sendMessage(this.messages.format("member-added", Map.of("player", offlinePlayer.getName() != null ? offlinePlayer.getName() : offlinePlayer.getUniqueId().toString(), "role", role2.name())));
        return true;
    }

    private boolean companyRemove(CommandSender commandSender, String[] stringArray) {
        if (!(commandSender instanceof Player)) {
            commandSender.sendMessage(this.messages.get("player-only"));
            return true;
        }
        if (stringArray.length < 4) {
            commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "Uso: /bm company remove <id> <player>");
            return true;
        }
        Player player = (Player)commandSender;
        Company company = this.dataStore.getCompany(stringArray[2]);
        if (company == null) {
            commandSender.sendMessage(this.messages.get("company-not-found"));
            return true;
        }
        if (!this.canManageCompany(player, company, Role.MANAGER)) {
            commandSender.sendMessage(this.messages.get("no-permission"));
            return true;
        }
        OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer((String)stringArray[3]);
        if (offlinePlayer == null || offlinePlayer.getUniqueId() == null) {
            commandSender.sendMessage(String.valueOf(ChatColor.RED) + "Giocatore non trovato.");
            return true;
        }
        if (company.getDirector() != null && company.getDirector().equals(offlinePlayer.getUniqueId())) {
            commandSender.sendMessage(String.valueOf(ChatColor.RED) + "Non puoi rimuovere il direttore.");
            return true;
        }
        company.removeMember(offlinePlayer.getUniqueId());
        commandSender.sendMessage(this.messages.format("member-removed", Map.of("player", offlinePlayer.getName() != null ? offlinePlayer.getName() : offlinePlayer.getUniqueId().toString())));
        return true;
    }

    private boolean companyRole(CommandSender commandSender, String[] stringArray) {
        if (!(commandSender instanceof Player)) {
            commandSender.sendMessage(this.messages.get("player-only"));
            return true;
        }
        if (stringArray.length < 5) {
            commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "Uso: /bm company role <id> <player> <ruolo>");
            return true;
        }
        Player player = (Player)commandSender;
        Company company = this.dataStore.getCompany(stringArray[2]);
        if (company == null) {
            commandSender.sendMessage(this.messages.get("company-not-found"));
            return true;
        }
        if (!this.canManageCompany(player, company, Role.MANAGER)) {
            commandSender.sendMessage(this.messages.get("no-permission"));
            return true;
        }
        OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer((String)stringArray[3]);
        if (offlinePlayer == null || offlinePlayer.getUniqueId() == null) {
            commandSender.sendMessage(String.valueOf(ChatColor.RED) + "Giocatore non trovato.");
            return true;
        }
        Role role = Role.fromString(stringArray[4]);
        if (company.getDirector() != null && company.getDirector().equals(offlinePlayer.getUniqueId()) && role != Role.DIRECTOR) {
            commandSender.sendMessage(String.valueOf(ChatColor.RED) + "Il direttore deve rimanere DIRECTOR.");
            return true;
        }
        company.addMember(offlinePlayer.getUniqueId(), role);
        commandSender.sendMessage(this.messages.format("role-updated", Map.of("player", offlinePlayer.getName() != null ? offlinePlayer.getName() : offlinePlayer.getUniqueId().toString(), "role", role.name())));
        return true;
    }

    private boolean companySetDirector(CommandSender commandSender, String[] stringArray) {
        if (!(commandSender instanceof Player)) {
            commandSender.sendMessage(this.messages.get("player-only"));
            return true;
        }
        if (stringArray.length < 4) {
            commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "Uso: /bm company setdirector <id> <player>");
            return true;
        }
        Company company = this.dataStore.getCompany(stringArray[2]);
        if (company == null) {
            commandSender.sendMessage(this.messages.get("company-not-found"));
            return true;
        }
        if (!this.isStaff(commandSender)) {
            commandSender.sendMessage(this.messages.get("no-permission"));
            return true;
        }
        OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer((String)stringArray[3]);
        if (offlinePlayer == null || offlinePlayer.getUniqueId() == null) {
            commandSender.sendMessage(String.valueOf(ChatColor.RED) + "Giocatore non trovato.");
            return true;
        }
        this.transferOwnership(company, offlinePlayer.getUniqueId());
        commandSender.sendMessage(this.messages.format("director-changed", Map.of("player", offlinePlayer.getName() != null ? offlinePlayer.getName() : offlinePlayer.getUniqueId().toString())));
        return true;
    }

    private boolean companySalary(CommandSender commandSender, String[] stringArray) {
        if (!(commandSender instanceof Player)) {
            commandSender.sendMessage(this.messages.get("player-only"));
            return true;
        }
        if (stringArray.length < 4) {
            commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "Uso: /bm company salary <set|start|stop|status|run> <id> ...");
            return true;
        }
        String string = stringArray[2].toLowerCase(Locale.ROOT);
        Company company = this.dataStore.getCompany(stringArray[3]);
        if (company == null) {
            commandSender.sendMessage(this.messages.get("company-not-found"));
            return true;
        }
        Player player = (Player)commandSender;
        if (!this.canManageCompany(player, company, Role.MANAGER)) {
            commandSender.sendMessage(this.messages.get("no-permission"));
            return true;
        }
        SalaryConfig salaryConfig = company.getSalaryConfig();
        switch (string) {
            case "set": {
                if (stringArray.length < 6) {
                    commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "Uso: /bm company salary set <id> <importo> <intervalloMin>");
                    return true;
                }
                Double d = CommandUtil.parseDouble(stringArray[4]);
                Integer n = CommandUtil.parseInt(stringArray[5]);
                if (d == null || d <= 0.0 || n == null || n <= 0) {
                    commandSender.sendMessage(this.messages.get("invalid-number"));
                    return true;
                }
                salaryConfig.setAmount(d);
                salaryConfig.setIntervalMinutes(n);
                commandSender.sendMessage(this.messages.format("salary-updated", Map.of("amount", this.economy.format(d), "interval", String.valueOf(n))));
                return true;
            }
            case "start": {
                salaryConfig.setEnabled(true);
                commandSender.sendMessage(this.messages.get("salary-started"));
                return true;
            }
            case "stop": {
                salaryConfig.setEnabled(false);
                commandSender.sendMessage(this.messages.get("salary-stopped"));
                return true;
            }
            case "status": {
                commandSender.sendMessage(String.valueOf(ChatColor.GOLD) + "Stipendi: " + (salaryConfig.isEnabled() ? "ON" : "OFF"));
                commandSender.sendMessage(String.valueOf(ChatColor.GRAY) + "Importo: " + this.economy.format(salaryConfig.getAmount()));
                commandSender.sendMessage(String.valueOf(ChatColor.GRAY) + "Intervallo: " + salaryConfig.getIntervalMinutes() + " min");
                return true;
            }
            case "run": {
                this.salaryScheduler.runForCompany(company, true);
                commandSender.sendMessage(String.valueOf(ChatColor.GREEN) + "Pagamento stipendi eseguito.");
                return true;
            }
        }
        commandSender.sendMessage(this.messages.get("unknown-command"));
        return true;
    }

    private boolean companySyncRoles(CommandSender commandSender, String[] stringArray) {
        if (!(commandSender instanceof Player)) {
            commandSender.sendMessage(this.messages.get("player-only"));
            return true;
        }
        if (!this.luckPerms.isEnabled()) {
            commandSender.sendMessage(String.valueOf(ChatColor.RED) + "LuckPerms non disponibile.");
            return true;
        }
        if (stringArray.length < 3) {
            commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "Uso: /bm company syncroles <id>");
            return true;
        }
        Company company = this.dataStore.getCompany(stringArray[2]);
        if (company == null) {
            commandSender.sendMessage(this.messages.get("company-not-found"));
            return true;
        }
        Player player = (Player)commandSender;
        if (!this.isStaff(commandSender)) {
            commandSender.sendMessage(this.messages.get("no-permission"));
            return true;
        }
        int n = 0;
        for (UUID uUID : company.getMembers().keySet()) {
            Role role = this.luckPerms.resolveRole(uUID);
            if (role == null || role == company.getRole(uUID)) continue;
            company.addMember(uUID, role);
            ++n;
        }
        commandSender.sendMessage(String.valueOf(ChatColor.GREEN) + "Ruoli sincronizzati: " + n);
        return true;
    }

    private boolean handleStock(CommandSender commandSender, String[] stringArray) {
        String string;
        if (stringArray.length < 2) {
            this.sendHelp(commandSender);
            return true;
        }
        switch (string = stringArray[1].toLowerCase(Locale.ROOT)) {
            case "create": {
                return this.stockCreate(commandSender, stringArray);
            }
            case "setprice": {
                return this.stockSetPrice(commandSender, stringArray);
            }
            case "info": {
                return this.stockInfo(commandSender, stringArray);
            }
            case "buy": {
                return this.stockBuy(commandSender, stringArray);
            }
            case "sell": {
                return this.stockSell(commandSender, stringArray);
            }
        }
        commandSender.sendMessage(this.messages.get("unknown-command"));
        return true;
    }

    private boolean stockCreate(CommandSender commandSender, String[] stringArray) {
        if (!(commandSender instanceof Player)) {
            commandSender.sendMessage(this.messages.get("player-only"));
            return true;
        }
        if (stringArray.length < 6) {
            commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "Uso: /bm stock create <companyId> <symbol> <totalShares> <price> [name]");
            return true;
        }
        Player player = (Player)commandSender;
        Company company = this.dataStore.getCompany(stringArray[2]);
        if (company == null) {
            commandSender.sendMessage(this.messages.get("company-not-found"));
            return true;
        }
        if (!this.canManageCompany(player, company, Role.DIRECTOR)) {
            commandSender.sendMessage(this.messages.get("no-permission"));
            return true;
        }
        String string = stringArray[3].toUpperCase(Locale.ROOT);
        Integer n = CommandUtil.parseInt(stringArray[4]);
        Double d = CommandUtil.parseDouble(stringArray[5]);
        if (n == null || n <= 0 || d == null || d <= 0.0) {
            commandSender.sendMessage(this.messages.get("invalid-number"));
            return true;
        }
        if (company.getStock(string) != null) {
            commandSender.sendMessage(this.messages.get("stock-exists"));
            return true;
        }
        double d2 = this.plugin.getConfig().getDouble("stocks.min-price", 1.0);
        double d3 = this.plugin.getConfig().getDouble("stocks.max-price", 100000.0);
        if (d < d2 || d > d3) {
            commandSender.sendMessage(String.valueOf(ChatColor.RED) + "Prezzo fuori range. Min: " + this.economy.format(d2) + " Max: " + this.economy.format(d3));
            return true;
        }
        double d4 = this.plugin.getConfig().getDouble("stocks.listing-fee", 0.0);
        if (d4 > 0.0 && company.getBalance() < d4) {
            commandSender.sendMessage(this.messages.get("company-insufficient-funds"));
            return true;
        }
        if (d4 > 0.0) {
            company.setBalance(company.getBalance() - d4);
        }
        Stock stock = new Stock();
        stock.setSymbol(string);
        stock.setName(stringArray.length > 6 ? TextUtil.join(stringArray, 6) : string);
        stock.setTotalShares(n);
        stock.setAvailableShares(n);
        stock.setPrice(d);
        stock.setLastPriceChangeEpoch(System.currentTimeMillis());
        company.addStock(stock);
        commandSender.sendMessage(this.messages.format("stock-created", Map.of("symbol", string, "company", company.getName())));
        return true;
    }

    private boolean stockSetPrice(CommandSender commandSender, String[] stringArray) {
        if (!(commandSender instanceof Player)) {
            commandSender.sendMessage(this.messages.get("player-only"));
            return true;
        }
        if (stringArray.length < 5) {
            commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "Uso: /bm stock setprice <companyId> <symbol> <price>");
            return true;
        }
        Player player = (Player)commandSender;
        Company company = this.dataStore.getCompany(stringArray[2]);
        if (company == null) {
            commandSender.sendMessage(this.messages.get("company-not-found"));
            return true;
        }
        if (!this.canManageCompany(player, company, Role.MANAGER)) {
            commandSender.sendMessage(this.messages.get("no-permission"));
            return true;
        }
        Stock stock = company.getStock(stringArray[3]);
        if (stock == null) {
            commandSender.sendMessage(String.valueOf(ChatColor.RED) + "Azione non trovata.");
            return true;
        }
        Double d = CommandUtil.parseDouble(stringArray[4]);
        if (d == null || d <= 0.0) {
            commandSender.sendMessage(this.messages.get("invalid-number"));
            return true;
        }
        double d2 = this.plugin.getConfig().getDouble("stocks.min-price", 1.0);
        double d3 = this.plugin.getConfig().getDouble("stocks.max-price", 100000.0);
        if (d < d2 || d > d3) {
            commandSender.sendMessage(String.valueOf(ChatColor.RED) + "Prezzo fuori range. Min: " + this.economy.format(d2) + " Max: " + this.economy.format(d3));
            return true;
        }
        long l = this.plugin.getConfig().getLong("stocks.price-change-cooldown-seconds", 60L) * 1000L;
        long l2 = System.currentTimeMillis();
        if (l2 - stock.getLastPriceChangeEpoch() < l) {
            commandSender.sendMessage(this.messages.get("cooldown"));
            return true;
        }
        stock.setPrice(d);
        stock.setLastPriceChangeEpoch(l2);
        commandSender.sendMessage(this.messages.format("stock-price-updated", Map.of("symbol", stock.getSymbol(), "price", this.economy.format(d))));
        return true;
    }

    private boolean stockInfo(CommandSender commandSender, String[] stringArray) {
        if (stringArray.length < 4) {
            commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "Uso: /bm stock info <companyId> <symbol>");
            return true;
        }
        Company company = this.dataStore.getCompany(stringArray[2]);
        if (company == null) {
            commandSender.sendMessage(this.messages.get("company-not-found"));
            return true;
        }
        Stock stock = company.getStock(stringArray[3]);
        if (stock == null) {
            commandSender.sendMessage(String.valueOf(ChatColor.RED) + "Azione non trovata.");
            return true;
        }
        commandSender.sendMessage(String.valueOf(ChatColor.GOLD) + "Azione " + stock.getSymbol() + " - " + stock.getName());
        commandSender.sendMessage(String.valueOf(ChatColor.GRAY) + "Prezzo: " + this.economy.format(stock.getPrice()));
        commandSender.sendMessage(String.valueOf(ChatColor.GRAY) + "Disponibili: " + stock.getAvailableShares() + " / " + stock.getTotalShares());
        return true;
    }

    private boolean stockBuy(CommandSender commandSender, String[] stringArray) {
        if (!(commandSender instanceof Player)) {
            commandSender.sendMessage(this.messages.get("player-only"));
            return true;
        }
        if (stringArray.length < 5) {
            commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "Uso: /bm stock buy <companyId> <symbol> <shares>");
            return true;
        }
        Player player = (Player)commandSender;
        Company company = this.dataStore.getCompany(stringArray[2]);
        if (company == null) {
            commandSender.sendMessage(this.messages.get("company-not-found"));
            return true;
        }
        Stock stock = company.getStock(stringArray[3]);
        if (stock == null) {
            commandSender.sendMessage(String.valueOf(ChatColor.RED) + "Azione non trovata.");
            return true;
        }
        Integer n = CommandUtil.parseInt(stringArray[4]);
        if (n == null || n <= 0) {
            commandSender.sendMessage(this.messages.get("invalid-number"));
            return true;
        }
        if (n > stock.getAvailableShares()) {
            commandSender.sendMessage(this.messages.get("stock-insufficient-shares"));
            return true;
        }
        double d = stock.getPrice() * (double)n.intValue();
        double d2 = this.plugin.getConfig().getDouble("stocks.transaction-fee-percent", 0.0);
        double d3 = d * (d2 / 100.0);
        double d4 = d + d3;
        if (!this.economy.withdrawPlayer(player.getUniqueId(), d4)) {
            commandSender.sendMessage(this.messages.get("player-insufficient-funds"));
            return true;
        }
        company.setBalance(company.getBalance() + d);
        stock.setAvailableShares(stock.getAvailableShares() - n);
        stock.addShares(player.getUniqueId(), n);
        commandSender.sendMessage(this.messages.format("stock-bought", Map.of("symbol", stock.getSymbol(), "shares", String.valueOf(n), "amount", this.economy.format(d4))));
        return true;
    }

    private boolean stockSell(CommandSender commandSender, String[] stringArray) {
        if (!(commandSender instanceof Player)) {
            commandSender.sendMessage(this.messages.get("player-only"));
            return true;
        }
        if (stringArray.length < 5) {
            commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "Uso: /bm stock sell <companyId> <symbol> <shares>");
            return true;
        }
        Player player = (Player)commandSender;
        Company company = this.dataStore.getCompany(stringArray[2]);
        if (company == null) {
            commandSender.sendMessage(this.messages.get("company-not-found"));
            return true;
        }
        Stock stock = company.getStock(stringArray[3]);
        if (stock == null) {
            commandSender.sendMessage(String.valueOf(ChatColor.RED) + "Azione non trovata.");
            return true;
        }
        Integer n = CommandUtil.parseInt(stringArray[4]);
        if (n == null || n <= 0) {
            commandSender.sendMessage(this.messages.get("invalid-number"));
            return true;
        }
        int n2 = stock.getHolderShares(player.getUniqueId());
        if (n > n2) {
            commandSender.sendMessage(this.messages.get("stock-insufficient-shares"));
            return true;
        }
        double d = stock.getPrice() * (double)n.intValue();
        double d2 = this.plugin.getConfig().getDouble("stocks.transaction-fee-percent", 0.0);
        double d3 = d * (d2 / 100.0);
        double d4 = d - d3;
        if (company.getBalance() < d4) {
            commandSender.sendMessage(this.messages.get("company-insufficient-funds"));
            return true;
        }
        company.setBalance(company.getBalance() - d4);
        stock.setAvailableShares(stock.getAvailableShares() + n);
        stock.removeShares(player.getUniqueId(), n);
        this.economy.depositPlayer(player.getUniqueId(), d4);
        commandSender.sendMessage(this.messages.format("stock-sold", Map.of("symbol", stock.getSymbol(), "shares", String.valueOf(n), "amount", this.economy.format(d4))));
        return true;
    }

    private boolean handleInvest(CommandSender commandSender, String[] stringArray) {
        String string;
        if (stringArray.length < 2) {
            this.sendHelp(commandSender);
            return true;
        }
        switch (string = stringArray[1].toLowerCase(Locale.ROOT)) {
            case "list": {
                return this.investList(commandSender, stringArray);
            }
            case "start": {
                return this.investStart(commandSender, stringArray);
            }
            case "status": {
                return this.investStatus(commandSender, stringArray);
            }
            case "claim": {
                return this.investClaim(commandSender, stringArray);
            }
        }
        commandSender.sendMessage(this.messages.get("unknown-command"));
        return true;
    }

    private boolean handleTransfer(CommandSender commandSender, String[] stringArray) {
        if (!this.isStaff(commandSender)) {
            commandSender.sendMessage(this.messages.get("no-permission"));
            return true;
        }
        if (stringArray.length < 4 || !stringArray[1].equalsIgnoreCase("ownership")) {
            commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "Uso: /bm transfer ownership <id> <player>");
            return true;
        }
        Company company = this.dataStore.getCompany(stringArray[2]);
        if (company == null) {
            commandSender.sendMessage(this.messages.get("company-not-found"));
            return true;
        }
        OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer((String)stringArray[3]);
        if (offlinePlayer == null || offlinePlayer.getUniqueId() == null) {
            commandSender.sendMessage(String.valueOf(ChatColor.RED) + "Giocatore non trovato.");
            return true;
        }
        this.transferOwnership(company, offlinePlayer.getUniqueId());
        commandSender.sendMessage(this.messages.format("ownership-transferred", Map.of("company", company.getName(), "player", offlinePlayer.getName() != null ? offlinePlayer.getName() : offlinePlayer.getUniqueId().toString())));
        return true;
    }

    private Map<String, InvestmentOption> loadInvestmentOptions() {
        HashMap<String, InvestmentOption> hashMap = new HashMap<String, InvestmentOption>();
        if (this.plugin.getConfig().getConfigurationSection("investments.options") == null) {
            return hashMap;
        }
        for (String string : this.plugin.getConfig().getConfigurationSection("investments.options").getKeys(false)) {
            String string2 = "investments.options." + string;
            String string3 = this.plugin.getConfig().getString(string2 + ".name", string);
            double d = this.plugin.getConfig().getDouble(string2 + ".min", 0.0);
            double d2 = this.plugin.getConfig().getDouble(string2 + ".max", 0.0);
            int n = this.plugin.getConfig().getInt(string2 + ".duration-minutes", 60);
            double d3 = this.plugin.getConfig().getDouble(string2 + ".return-multiplier", 1.0);
            hashMap.put(string.toLowerCase(Locale.ROOT), new InvestmentOption(string.toLowerCase(Locale.ROOT), string3, d, d2, n, d3));
        }
        return hashMap;
    }

    private boolean investList(CommandSender commandSender, String[] stringArray) {
        if (stringArray.length < 3) {
            commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "Uso: /bm invest list <companyId>");
            return true;
        }
        Company company = this.dataStore.getCompany(stringArray[2]);
        if (company == null) {
            commandSender.sendMessage(this.messages.get("company-not-found"));
            return true;
        }
        commandSender.sendMessage(String.valueOf(ChatColor.GOLD) + "Opzioni investimento per " + company.getName() + ":");
        for (InvestmentOption investmentOption : this.loadInvestmentOptions().values()) {
            commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "- " + investmentOption.getId() + " | " + investmentOption.getName() + String.valueOf(ChatColor.GRAY) + " min: " + this.economy.format(investmentOption.getMin()) + " max: " + this.economy.format(investmentOption.getMax()) + " durata: " + investmentOption.getDurationMinutes() + " min x" + investmentOption.getReturnMultiplier());
        }
        return true;
    }

    private boolean investStart(CommandSender commandSender, String[] stringArray) {
        if (!(commandSender instanceof Player)) {
            commandSender.sendMessage(this.messages.get("player-only"));
            return true;
        }
        if (stringArray.length < 5) {
            commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "Uso: /bm invest start <companyId> <optionId> <amount>");
            return true;
        }
        Player player = (Player)commandSender;
        Company company = this.dataStore.getCompany(stringArray[2]);
        if (company == null) {
            commandSender.sendMessage(this.messages.get("company-not-found"));
            return true;
        }
        if (!this.canManageCompany(player, company, Role.MANAGER)) {
            commandSender.sendMessage(this.messages.get("no-permission"));
            return true;
        }
        Map<String, InvestmentOption> map = this.loadInvestmentOptions();
        InvestmentOption investmentOption = map.get(stringArray[3].toLowerCase(Locale.ROOT));
        if (investmentOption == null) {
            commandSender.sendMessage(this.messages.get("invest-option-not-found"));
            return true;
        }
        Double d = CommandUtil.parseDouble(stringArray[4]);
        if (d == null || d <= 0.0) {
            commandSender.sendMessage(this.messages.get("invalid-number"));
            return true;
        }
        if (d < investmentOption.getMin() || d > investmentOption.getMax()) {
            commandSender.sendMessage(String.valueOf(ChatColor.RED) + "Importo fuori range. Min: " + this.economy.format(investmentOption.getMin()) + " Max: " + this.economy.format(investmentOption.getMax()));
            return true;
        }
        if (company.getBalance() < d) {
            commandSender.sendMessage(this.messages.get("company-insufficient-funds"));
            return true;
        }
        company.setBalance(company.getBalance() - d);
        Investment investment = new Investment();
        String string = "inv-" + System.currentTimeMillis();
        investment.setId(string);
        investment.setOptionId(investmentOption.getId());
        investment.setPrincipal(d);
        investment.setStartEpoch(System.currentTimeMillis());
        investment.setDurationMinutes(investmentOption.getDurationMinutes());
        investment.setReturnMultiplier(investmentOption.getReturnMultiplier());
        investment.setClaimed(false);
        company.addInvestment(investment);
        commandSender.sendMessage(this.messages.format("invest-started", Map.of("investment", string, "amount", this.economy.format(d))));
        return true;
    }

    private boolean investStatus(CommandSender commandSender, String[] stringArray) {
        if (stringArray.length < 3) {
            commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "Uso: /bm invest status <companyId>");
            return true;
        }
        Company company = this.dataStore.getCompany(stringArray[2]);
        if (company == null) {
            commandSender.sendMessage(this.messages.get("company-not-found"));
            return true;
        }
        commandSender.sendMessage(String.valueOf(ChatColor.GOLD) + "Investimenti per " + company.getName() + ":");
        long l = System.currentTimeMillis();
        for (Investment investment : company.getActiveInvestments()) {
            String string = investment.isClaimed() ? "CLAIMED" : (investment.isMatured(l) ? "READY" : "RUNNING");
            commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "- " + investment.getId() + String.valueOf(ChatColor.GRAY) + " " + investment.getOptionId() + " " + this.economy.format(investment.getPrincipal()) + " x" + investment.getReturnMultiplier() + " " + string);
        }
        return true;
    }

    private boolean investClaim(CommandSender commandSender, String[] stringArray) {
        if (!(commandSender instanceof Player)) {
            commandSender.sendMessage(this.messages.get("player-only"));
            return true;
        }
        if (stringArray.length < 4) {
            commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "Uso: /bm invest claim <companyId> <investmentId>");
            return true;
        }
        Player player = (Player)commandSender;
        Company company = this.dataStore.getCompany(stringArray[2]);
        if (company == null) {
            commandSender.sendMessage(this.messages.get("company-not-found"));
            return true;
        }
        if (!this.canManageCompany(player, company, Role.MANAGER)) {
            commandSender.sendMessage(this.messages.get("no-permission"));
            return true;
        }
        Investment investment = company.getInvestment(stringArray[3]);
        if (investment == null) {
            commandSender.sendMessage(String.valueOf(ChatColor.RED) + "Investimento non trovato.");
            return true;
        }
        long l = System.currentTimeMillis();
        if (!investment.isMatured(l)) {
            commandSender.sendMessage(this.messages.get("invest-not-ready"));
            return true;
        }
        if (investment.isClaimed()) {
            commandSender.sendMessage(String.valueOf(ChatColor.RED) + "Investimento gia riscattato.");
            return true;
        }
        double d = investment.getReturnAmount();
        company.setBalance(company.getBalance() + d);
        investment.setClaimed(true);
        commandSender.sendMessage(this.messages.format("invest-claimed", Map.of("investment", investment.getId(), "amount", this.economy.format(d))));
        return true;
    }

    private boolean handleSpiega(CommandSender commandSender) {
        String string = this.messages.get("prefix");
        commandSender.sendMessage(string + String.valueOf(ChatColor.GOLD) + "Guida BusinessManager (1.17.1)");
        commandSender.sendMessage(string + String.valueOf(ChatColor.GRAY) + "Requisiti: " + String.valueOf(ChatColor.YELLOW) + "Vault + plugin economia" + String.valueOf(ChatColor.GRAY) + " (es. EssentialsX).");
        commandSender.sendMessage(string + String.valueOf(ChatColor.YELLOW) + "1) Crea azienda (staff): " + String.valueOf(ChatColor.WHITE) + "/bm company create <id> <nome>");
        commandSender.sendMessage(string + String.valueOf(ChatColor.YELLOW) + "2) Info e lista: " + String.valueOf(ChatColor.WHITE) + "/bm company info <id>" + String.valueOf(ChatColor.GRAY) + " / " + String.valueOf(ChatColor.WHITE) + "/bm company list");
        commandSender.sendMessage(string + String.valueOf(ChatColor.YELLOW) + "3) Aggiungi membri: " + String.valueOf(ChatColor.WHITE) + "/bm company add <id> <player> [ruolo]");
        commandSender.sendMessage(string + String.valueOf(ChatColor.YELLOW) + "4) Cambia ruolo: " + String.valueOf(ChatColor.WHITE) + "/bm company role <id> <player> <ruolo>");
        commandSender.sendMessage(string + String.valueOf(ChatColor.YELLOW) + "5) Depositi (manager): " + String.valueOf(ChatColor.WHITE) + "/bm company deposit <id> <importo>");
        commandSender.sendMessage(string + String.valueOf(ChatColor.YELLOW) + "6) Prelievi (staff): " + String.valueOf(ChatColor.WHITE) + "/bm company withdraw <id> <importo>");
        commandSender.sendMessage(string + String.valueOf(ChatColor.YELLOW) + "7) Stipendi: " + String.valueOf(ChatColor.WHITE) + "/bm company salary set <id> <importo> <intervalloMin>");
        commandSender.sendMessage(string + String.valueOf(ChatColor.GRAY) + "   Poi: " + String.valueOf(ChatColor.WHITE) + "/bm company salary start|stop|status|run <id>");
        commandSender.sendMessage(string + String.valueOf(ChatColor.GRAY) + "   I salari usano il saldo aziendale e pagano i ruoli in config.");
        commandSender.sendMessage(string + String.valueOf(ChatColor.YELLOW) + "8) Investimenti: " + String.valueOf(ChatColor.WHITE) + "/bm invest list|start|status|claim <id>");
        commandSender.sendMessage(string + String.valueOf(ChatColor.YELLOW) + "9) Trasferisci proprieta (staff): " + String.valueOf(ChatColor.WHITE) + "/bm transfer ownership <id> <player>");
        commandSender.sendMessage(string + String.valueOf(ChatColor.GRAY) + "Placeholder soldi formattati: " + String.valueOf(ChatColor.YELLOW) + "%vault_eco_balance_formatted%");
        commandSender.sendMessage(string + String.valueOf(ChatColor.GRAY) + "Saldo personale: usa /balance del tuo plugin economia.");
        return true;
    }

    private void sendHelp(CommandSender commandSender) {
        boolean bl = this.isStaff(commandSender);
        commandSender.sendMessage(String.valueOf(ChatColor.GOLD) + "BusinessManager comandi:");
        if (bl) {
            commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "/bm company create <id> <nome>");
            commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "/bm transfer ownership <id> <player>");
            commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "/bm company syncroles <id>");
        }
        commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "/bm spiega");
        commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "/bm company info <id>");
        commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "/bm company list");
        commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "/bm company deposit <id> <importo>");
        commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "/bm company withdraw <id> <importo>");
        commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "/bm company add <id> <player> [ruolo]");
        commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "/bm company remove <id> <player>");
        commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "/bm company role <id> <player> <ruolo>");
        commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "/bm company salary set <id> <importo> <intervalloMin>");
        commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "/bm company salary start|stop|status|run <id>");
        commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "/bm invest list <companyId>");
        commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "/bm invest start <companyId> <optionId> <amount>");
        commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "/bm invest status <companyId>");
        commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "/bm invest claim <companyId> <investmentId>");
        if (bl) {
            commandSender.sendMessage(String.valueOf(ChatColor.YELLOW) + "/bm reload");
        }
    }

    private boolean isStaff(CommandSender commandSender) {
        return commandSender.hasPermission("bm.staff");
    }

    private boolean isAdmin(CommandSender commandSender) {
        return commandSender.hasPermission("bm.admin");
    }

    private boolean canUseBm(CommandSender commandSender) {
        return this.isStaff(commandSender) || this.isAdmin(commandSender);
    }

    private boolean canUseSpiega(CommandSender commandSender) {
        if (this.canUseBm(commandSender)) {
            return true;
        }
        if (!(commandSender instanceof Player)) {
            return false;
        }
        Player player = (Player)commandSender;
        return this.dataStore.getCompanyCountForDirector(player.getUniqueId()) > 0;
    }

    private boolean canManageCompany(Player player, Company company, Role role) {
        if (this.isStaff((CommandSender)player)) {
            return true;
        }
        if (!this.isAdmin((CommandSender)player)) {
            return false;
        }
        Role role2 = company.getRole(player.getUniqueId());
        return this.roleRank(role2) >= this.roleRank(role);
    }

    private void transferOwnership(Company company, UUID uUID) {
        UUID uUID2 = company.getDirector();
        if (uUID2 != null && !uUID2.equals(uUID)) {
            company.addMember(uUID2, Role.MANAGER);
        }
        company.setDirector(uUID);
        company.addMember(uUID, Role.DIRECTOR);
    }

    private int roleRank(Role role) {
        switch (role) {
            case DIRECTOR: {
                return 3;
            }
            case MANAGER: {
                return 2;
            }
        }
        return 1;
    }

    public List<String> onTabComplete(CommandSender commandSender, Command command, String string, String[] stringArray) {
        ArrayList<String> arrayList = new ArrayList<String>();
        boolean bl = this.canUseBm(commandSender);
        boolean bl2 = this.canUseSpiega(commandSender);
        if (!bl && !bl2) {
            return arrayList;
        }
        if (stringArray.length == 1) {
            arrayList.add("help");
            if (bl2) {
                arrayList.add("spiega");
            }
            if (bl) {
                arrayList.add("company");
                arrayList.add("invest");
            }
            if (this.isStaff(commandSender)) {
                arrayList.add("reload");
                arrayList.add("transfer");
            }
            return this.filter(arrayList, stringArray[0]);
        }
        if (!bl) {
            return arrayList;
        }
        if (stringArray.length >= 2 && stringArray[0].equalsIgnoreCase("company")) {
            if (stringArray.length == 2) {
                arrayList.add("info");
                arrayList.add("list");
                arrayList.add("deposit");
                arrayList.add("withdraw");
                arrayList.add("add");
                arrayList.add("remove");
                arrayList.add("role");
                arrayList.add("salary");
                if (this.isStaff(commandSender)) {
                    arrayList.add("create");
                    arrayList.add("setdirector");
                    arrayList.add("syncroles");
                }
                return this.filter(arrayList, stringArray[1]);
            }
            if (stringArray.length == 3 && !stringArray[1].equalsIgnoreCase("create")) {
                for (Company company : this.dataStore.getCompanies()) {
                    arrayList.add(company.getId());
                }
                return this.filter(arrayList, stringArray[2]);
            }
        }
        if (stringArray.length >= 2 && stringArray[0].equalsIgnoreCase("invest") && stringArray.length == 2) {
            arrayList.add("list");
            arrayList.add("start");
            arrayList.add("status");
            arrayList.add("claim");
            return this.filter(arrayList, stringArray[1]);
        }
        if (stringArray.length >= 2 && stringArray[0].equalsIgnoreCase("transfer")) {
            if (stringArray.length == 2) {
                arrayList.add("ownership");
                return this.filter(arrayList, stringArray[1]);
            }
            if (stringArray.length == 3 && stringArray[1].equalsIgnoreCase("ownership")) {
                for (Company company : this.dataStore.getCompanies()) {
                    arrayList.add(company.getId());
                }
                return this.filter(arrayList, stringArray[2]);
            }
            if (stringArray.length == 4 && stringArray[1].equalsIgnoreCase("ownership")) {
                for (Player player : Bukkit.getOnlinePlayers()) {
                    arrayList.add(player.getName());
                }
                return this.filter(arrayList, stringArray[3]);
            }
        }
        return arrayList;
    }

    private List<String> filter(List<String> list, String string) {
        ArrayList<String> arrayList = new ArrayList<String>();
        String string2 = string.toLowerCase(Locale.ROOT);
        for (String string3 : list) {
            if (!string3.toLowerCase(Locale.ROOT).startsWith(string2)) continue;
            arrayList.add(string3);
        }
        return arrayList;
    }
}

