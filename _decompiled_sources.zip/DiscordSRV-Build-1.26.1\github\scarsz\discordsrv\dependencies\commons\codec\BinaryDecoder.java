/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.codec;

import github.scarsz.discordsrv.dependencies.commons.codec.Decoder;
import github.scarsz.discordsrv.dependencies.commons.codec.DecoderException;

public interface BinaryDecoder
extends Decoder {
    public byte[] decode(byte[] var1) throws DecoderException;
}

