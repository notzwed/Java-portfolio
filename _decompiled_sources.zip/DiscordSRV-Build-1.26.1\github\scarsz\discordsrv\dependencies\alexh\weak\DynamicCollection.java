/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.alexh.weak;

import github.scarsz.discordsrv.dependencies.alexh.LiteJoiner;
import github.scarsz.discordsrv.dependencies.alexh.weak.AbstractDynamic;
import github.scarsz.discordsrv.dependencies.alexh.weak.ChildAbsence;
import github.scarsz.discordsrv.dependencies.alexh.weak.Describer;
import github.scarsz.discordsrv.dependencies.alexh.weak.Dynamic;
import github.scarsz.discordsrv.dependencies.alexh.weak.DynamicChild;
import github.scarsz.discordsrv.dependencies.alexh.weak.DynamicChildLogic;
import github.scarsz.discordsrv.dependencies.alexh.weak.ParentAbsence;
import java.util.Collection;
import java.util.Set;
import java.util.stream.Stream;

class DynamicCollection
extends AbstractDynamic<Collection>
implements Dynamic,
Describer {
    static final String NO_KEY = "?";

    DynamicCollection(Collection inner) {
        super(inner);
    }

    @Override
    protected Object keyLiteral() {
        return "root";
    }

    @Override
    public Dynamic get(Object childKey) {
        if (((Collection)this.inner).isEmpty()) {
            return new ParentAbsence.Empty<DynamicCollection>(this, childKey);
        }
        return new ChildAbsence.Missing<DynamicCollection>(this, childKey);
    }

    @Override
    public Stream<Dynamic> children() {
        return ((Collection)this.inner).stream().map(val -> val == null ? new ChildAbsence.Null(this, (Object)NO_KEY) : DynamicChild.from(this, NO_KEY, val));
    }

    @Override
    public String describe() {
        String type;
        String string = type = this.inner instanceof Set ? "Set" : "Collection";
        if (((Collection)this.inner).isEmpty()) {
            return "Empty-" + type;
        }
        return type + "[size:" + ((Collection)this.inner).size() + "]";
    }

    public String toString() {
        return this.keyLiteral() + ":" + this.describe();
    }

    static class Child
    extends DynamicCollection
    implements DynamicChild {
        private final Dynamic parent;
        private final Object key;

        Child(Dynamic parent, Object key, Collection inner) {
            super(inner);
            this.parent = parent;
            this.key = key;
        }

        @Override
        public Dynamic parent() {
            return this.parent;
        }

        @Override
        public Object keyLiteral() {
            return this.key;
        }

        @Override
        public String toString() {
            return LiteJoiner.on("->").join(DynamicChildLogic.using(this).getAscendingKeyChainWithRoot()) + ":" + this.describe();
        }
    }
}

