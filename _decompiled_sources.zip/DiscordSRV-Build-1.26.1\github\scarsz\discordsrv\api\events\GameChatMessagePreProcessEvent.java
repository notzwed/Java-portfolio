/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Cancellable
 *  org.bukkit.event.Event
 */
package github.scarsz.discordsrv.api.events;

import github.scarsz.discordsrv.api.events.GameEvent;
import github.scarsz.discordsrv.dependencies.kyori.adventure.text.Component;
import github.scarsz.discordsrv.util.MessageUtil;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;

public class GameChatMessagePreProcessEvent
extends GameEvent<Event>
implements Cancellable {
    private boolean cancelled;
    private String channel;
    private Component messageComponent;

    public GameChatMessagePreProcessEvent(String channel, Component message, Player player, Event event) {
        super(player, event);
        this.channel = channel;
        this.messageComponent = message;
    }

    @Deprecated
    public GameChatMessagePreProcessEvent(String channel, Component message, Player player) {
        this(channel, message, player, null);
    }

    @Deprecated
    public GameChatMessagePreProcessEvent(String channel, String message, Player player) {
        this(channel, MessageUtil.toComponent(message, true), player);
    }

    @Deprecated
    public String getMessage() {
        return MessageUtil.toLegacy(this.messageComponent);
    }

    @Deprecated
    public void setMessage(String legacy) {
        this.messageComponent = MessageUtil.toComponent(legacy, true);
    }

    public boolean isCancelled() {
        return this.cancelled;
    }

    public void setCancelled(boolean cancelled) {
        this.cancelled = cancelled;
    }

    public String getChannel() {
        return this.channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public Component getMessageComponent() {
        return this.messageComponent;
    }

    public void setMessageComponent(Component messageComponent) {
        this.messageComponent = messageComponent;
    }
}

