/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.api.commands;

import github.scarsz.discordsrv.api.commands.SlashCommandPriority;
import github.scarsz.discordsrv.api.commands.SlashCommands;
import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Repeatable(value=SlashCommands.class)
@Retention(value=RetentionPolicy.RUNTIME)
@Target(value={ElementType.METHOD})
public @interface SlashCommand {
    public String path();

    public SlashCommandPriority priority() default SlashCommandPriority.NORMAL;

    public boolean deferReply() default false;

    public boolean deferEphemeral() default false;

    public boolean ignoreAcknowledged() default false;
}

