/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.plugin.java.JavaPlugin
 */
package it.marco.businessmanager.util;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

public class MessageManager {
    private final JavaPlugin plugin;
    private FileConfiguration messages;
    private String prefix;

    public MessageManager(JavaPlugin plugin) {
        this.plugin = plugin;
        this.reload();
    }

    public void reload() {
        String lang = this.plugin.getConfig().getString("language", "it_IT").toLowerCase();
        String base = lang.split("[_-]")[0];
        String fileName = "messages_" + base + ".yml";
        File file = new File(this.plugin.getDataFolder(), fileName);
        if (!file.exists()) {
            try {
                this.plugin.getDataFolder().mkdirs();
                this.plugin.saveResource(fileName, false);
            }
            catch (IllegalArgumentException illegalArgumentException) {
                // empty catch block
            }
        }
        if (!file.exists() && !(file = new File(this.plugin.getDataFolder(), "messages_it.yml")).exists()) {
            try {
                this.plugin.saveResource("messages_it.yml", false);
            }
            catch (IllegalArgumentException illegalArgumentException) {
                // empty catch block
            }
        }
        this.messages = YamlConfiguration.loadConfiguration((File)file);
        this.prefix = this.messages.getString("prefix", "&6[Business]&r ");
        String configPrefix = this.plugin.getConfig().getString("messages.prefix", null);
        if (configPrefix != null && !configPrefix.isEmpty()) {
            this.prefix = configPrefix;
        }
    }

    public String get(String key) {
        String msg = this.messages.getString(key, key);
        msg = msg.replace("{prefix}", this.prefix);
        return this.color(msg);
    }

    public String format(String key, Map<String, String> placeholders) {
        String msg = this.get(key);
        for (Map.Entry<String, String> entry : placeholders.entrySet()) {
            msg = msg.replace("{" + entry.getKey() + "}", entry.getValue());
        }
        return this.color(msg);
    }

    public String color(String msg) {
        return ChatColor.translateAlternateColorCodes((char)'&', (String)msg);
    }

    public void saveDefaults() {
        try {
            this.messages.save(new File(this.plugin.getDataFolder(), "messages_it.yml"));
        }
        catch (IOException iOException) {
            // empty catch block
        }
    }
}

