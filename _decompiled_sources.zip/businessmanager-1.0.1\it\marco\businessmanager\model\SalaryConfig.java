/*
 * Decompiled with CFR 0.152.
 */
package it.marco.businessmanager.model;

import it.marco.businessmanager.model.Role;
import java.util.EnumSet;
import java.util.Set;

public class SalaryConfig {
    private double amount;
    private int intervalMinutes;
    private boolean enabled;
    private long lastPaidEpoch;
    private final Set<Role> payRoles = EnumSet.noneOf(Role.class);

    public double getAmount() {
        return this.amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public int getIntervalMinutes() {
        return this.intervalMinutes;
    }

    public void setIntervalMinutes(int intervalMinutes) {
        this.intervalMinutes = intervalMinutes;
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public long getLastPaidEpoch() {
        return this.lastPaidEpoch;
    }

    public void setLastPaidEpoch(long lastPaidEpoch) {
        this.lastPaidEpoch = lastPaidEpoch;
    }

    public Set<Role> getPayRoles() {
        return this.payRoles;
    }
}

