/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.ConsoleCommandSender
 */
package github.scarsz.discordsrv.commands;

import github.scarsz.discordsrv.commands.Command;
import github.scarsz.discordsrv.util.DebugUtil;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;

public class CommandDebug {
    @Command(commandNames={"debug"}, helpMessage="Dumps DiscordSRV debug information to bin.scarsz.me", permission="discordsrv.debug")
    public static void execute(CommandSender sender, String[] args) {
        String result = DebugUtil.run(sender instanceof ConsoleCommandSender ? "CONSOLE" : sender.getName(), args.length == 0 ? 256 : Integer.parseInt(args[0]));
        sender.sendMessage(ChatColor.DARK_AQUA + "Your debug report has been generated and is available at " + ChatColor.AQUA + result);
    }
}

