/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.io.filefilter;

import github.scarsz.discordsrv.dependencies.commons.io.IOUtils;
import github.scarsz.discordsrv.dependencies.commons.io.filefilter.AbstractFileFilter;
import github.scarsz.discordsrv.dependencies.commons.io.filefilter.IOFileFilter;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.stream.Stream;

public class EmptyFileFilter
extends AbstractFileFilter
implements Serializable {
    public static final IOFileFilter EMPTY = new EmptyFileFilter();
    public static final IOFileFilter NOT_EMPTY = EMPTY.negate();
    private static final long serialVersionUID = 3631422087512832211L;

    protected EmptyFileFilter() {
    }

    @Override
    public boolean accept(File file) {
        if (file.isDirectory()) {
            Object[] files = file.listFiles();
            return IOUtils.length((Object[])files) == 0;
        }
        return file.length() == 0L;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public FileVisitResult accept(Path file, BasicFileAttributes attributes) {
        try {
            boolean bl;
            if (Files.isDirectory(file, new LinkOption[0])) {
                try (Stream<Path> stream = Files.list(file);){
                    FileVisitResult fileVisitResult = EmptyFileFilter.toFileVisitResult((!stream.findFirst().isPresent() ? 1 : 0) != 0, (Path)file);
                    return fileVisitResult;
                }
            }
            if (Files.size(file) == 0L) {
                bl = true;
                return EmptyFileFilter.toFileVisitResult((boolean)bl, (Path)file);
            }
            bl = false;
            return EmptyFileFilter.toFileVisitResult((boolean)bl, (Path)file);
        }
        catch (IOException e) {
            return this.handle(e);
        }
    }
}

