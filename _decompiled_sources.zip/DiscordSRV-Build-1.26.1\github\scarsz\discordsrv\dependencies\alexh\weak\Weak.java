/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.alexh.weak;

import github.scarsz.discordsrv.dependencies.alexh.weak.Converter;
import github.scarsz.discordsrv.dependencies.alexh.weak.OptionalWeak;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public interface Weak<Self extends Weak<Self>> {
    public boolean isPresent();

    public Object asObject();

    default public Optional<Object> asOptional() {
        return this.isPresent() ? Optional.of(this.asObject()) : Optional.empty();
    }

    default public <T> T as(Class<T> type) {
        return type.cast(this.asObject());
    }

    default public String asString() {
        return this.as(String.class);
    }

    default public <T> List<T> asList() {
        return this.as(List.class);
    }

    default public <K, V> Map<K, V> asMap() {
        return this.as(Map.class);
    }

    default public boolean is(Class<?> type) {
        return this.isPresent() && type.isInstance(this.asObject());
    }

    default public boolean isMap() {
        return this.is(Map.class);
    }

    default public boolean isString() {
        return this.is(String.class);
    }

    default public boolean isList() {
        return this.is(List.class);
    }

    default public Converter convert() {
        return Converter.convert(this.asObject());
    }

    default public OptionalWeak<Self> maybe() {
        return this.isPresent() ? OptionalWeak.of(this) : OptionalWeak.empty();
    }
}

