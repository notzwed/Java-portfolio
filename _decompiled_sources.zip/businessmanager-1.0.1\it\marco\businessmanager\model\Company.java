/*
 * Decompiled with CFR 0.152.
 */
package it.marco.businessmanager.model;

import it.marco.businessmanager.model.Investment;
import it.marco.businessmanager.model.Role;
import it.marco.businessmanager.model.SalaryConfig;
import it.marco.businessmanager.model.Stock;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class Company {
    private String id;
    private String name;
    private UUID director;
    private double balance;
    private SalaryConfig salaryConfig;
    private final Map<UUID, Role> members = new HashMap<UUID, Role>();
    private final Map<String, Stock> stocks = new HashMap<String, Stock>();
    private final Map<String, Investment> investments = new HashMap<String, Investment>();

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public UUID getDirector() {
        return this.director;
    }

    public void setDirector(UUID director) {
        this.director = director;
        this.members.put(director, Role.DIRECTOR);
    }

    public double getBalance() {
        return this.balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public SalaryConfig getSalaryConfig() {
        return this.salaryConfig;
    }

    public void setSalaryConfig(SalaryConfig salaryConfig) {
        this.salaryConfig = salaryConfig;
    }

    public Map<UUID, Role> getMembers() {
        return this.members;
    }

    public Role getRole(UUID uuid) {
        return this.members.getOrDefault(uuid, Role.EMPLOYEE);
    }

    public boolean isMember(UUID uuid) {
        return this.members.containsKey(uuid);
    }

    public void addMember(UUID uuid, Role role) {
        this.members.put(uuid, role);
    }

    public void removeMember(UUID uuid) {
        this.members.remove(uuid);
    }

    public Map<String, Stock> getStocks() {
        return this.stocks;
    }

    public Stock getStock(String symbol) {
        return this.stocks.get(symbol.toUpperCase());
    }

    public void addStock(Stock stock) {
        this.stocks.put(stock.getSymbol().toUpperCase(), stock);
    }

    public Map<String, Investment> getInvestments() {
        return this.investments;
    }

    public Investment getInvestment(String id) {
        return this.investments.get(id);
    }

    public void addInvestment(Investment investment) {
        this.investments.put(investment.getId(), investment);
    }

    public List<Investment> getActiveInvestments() {
        return new ArrayList<Investment>(this.investments.values());
    }
}

