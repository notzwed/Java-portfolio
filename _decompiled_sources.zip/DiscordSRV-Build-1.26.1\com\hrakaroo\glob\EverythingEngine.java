/*
 * Decompiled with CFR 0.152.
 */
package com.hrakaroo.glob;

import com.hrakaroo.glob.MatchingEngine;

class EverythingEngine
implements MatchingEngine {
    static final EverythingEngine EVERYTHING_ENGINE = new EverythingEngine();

    private EverythingEngine() {
    }

    @Override
    public boolean matches(String string) {
        return string != null;
    }

    @Override
    public int matchingSizeInBytes() {
        return 0;
    }

    @Override
    public int staticSizeInBytes() {
        return 0;
    }
}

