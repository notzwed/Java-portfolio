/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.collections4;

import github.scarsz.discordsrv.dependencies.commons.collections4.OrderedIterator;
import github.scarsz.discordsrv.dependencies.commons.collections4.ResettableIterator;
import java.util.ListIterator;

public interface ResettableListIterator<E>
extends ListIterator<E>,
ResettableIterator<E>,
OrderedIterator<E> {
}

