/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.io.filefilter;

import github.scarsz.discordsrv.dependencies.commons.io.filefilter.IOFileFilter;
import java.io.File;

public abstract class AbstractFileFilter
implements IOFileFilter {
    @Override
    public boolean accept(File file) {
        return this.accept(file.getParentFile(), file.getName());
    }

    @Override
    public boolean accept(File dir, String name) {
        return this.accept(new File(dir, name));
    }

    public String toString() {
        return this.getClass().getSimpleName();
    }
}

