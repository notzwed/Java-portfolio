/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.alexh.weak;

import github.scarsz.discordsrv.dependencies.alexh.weak.DynamicChild;
import java.util.List;

interface IssueDescribingChild
extends DynamicChild {
    public String describeIssue(List<Object> var1);
}

