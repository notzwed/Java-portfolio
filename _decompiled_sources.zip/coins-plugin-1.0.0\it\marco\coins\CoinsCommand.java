/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.entity.Player
 */
package it.marco.coins;

import it.marco.coins.CoinsManager;
import it.marco.coins.CoinsPlugin;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public class CoinsCommand
implements CommandExecutor,
TabCompleter {
    private final CoinsPlugin plugin;

    public CoinsCommand(CoinsPlugin plugin) {
        this.plugin = plugin;
    }

    private CoinsManager manager() {
        return this.plugin.getCoinsManager();
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            if (sender instanceof Player) {
                Player player = (Player)sender;
                int balance = this.manager().getBalance(player.getUniqueId());
                sender.sendMessage(String.valueOf(ChatColor.GOLD) + "Coins: " + String.valueOf(ChatColor.YELLOW) + balance);
                return true;
            }
            sender.sendMessage(String.valueOf(ChatColor.RED) + "Usa: /coins set|add|remove|reset <player> <amount>");
            return true;
        }
        String sub = args[0].toLowerCase();
        if (this.isAdminSub(sub)) {
            int amount;
            String targetName;
            if (!sender.hasPermission("coins.admin")) {
                sender.sendMessage(String.valueOf(ChatColor.RED) + "Non hai il permesso.");
                return true;
            }
            if (args.length < 2) {
                sender.sendMessage(String.valueOf(ChatColor.RED) + "Usa: /coins " + sub + " <player>" + (sub.equals("reset") ? "" : " <amount>"));
                return true;
            }
            OfflinePlayer target = Bukkit.getOfflinePlayer((String)args[1]);
            if (target == null || !target.isOnline() && !target.hasPlayedBefore()) {
                sender.sendMessage(String.valueOf(ChatColor.RED) + "Giocatore non trovato.");
                return true;
            }
            String string = targetName = target.getName() != null ? target.getName() : args[1];
            if (sub.equals("reset")) {
                this.manager().setBalance(target.getUniqueId(), 0);
                this.manager().save();
                sender.sendMessage(String.valueOf(ChatColor.GREEN) + "Coins resettati per " + targetName + ".");
                return true;
            }
            if (args.length < 3) {
                sender.sendMessage(String.valueOf(ChatColor.RED) + "Usa: /coins " + sub + " <player> <amount>");
                return true;
            }
            try {
                amount = Integer.parseInt(args[2]);
            }
            catch (NumberFormatException e) {
                sender.sendMessage(String.valueOf(ChatColor.RED) + "Amount non valido.");
                return true;
            }
            if (amount < 0) {
                sender.sendMessage(String.valueOf(ChatColor.RED) + "Amount non valido.");
                return true;
            }
            switch (sub) {
                case "set": {
                    this.manager().setBalance(target.getUniqueId(), amount);
                    break;
                }
                case "add": {
                    this.manager().addBalance(target.getUniqueId(), amount);
                    break;
                }
                case "remove": {
                    this.manager().removeBalance(target.getUniqueId(), amount);
                    break;
                }
                default: {
                    sender.sendMessage(String.valueOf(ChatColor.RED) + "Subcomando non valido.");
                    return true;
                }
            }
            this.manager().save();
            sender.sendMessage(String.valueOf(ChatColor.GREEN) + "Coins aggiornati per " + targetName + ".");
            return true;
        }
        if (sub.equals("balance") || sub.equals("bal")) {
            if (sender instanceof Player) {
                Player player = (Player)sender;
                int balance = this.manager().getBalance(player.getUniqueId());
                sender.sendMessage(String.valueOf(ChatColor.GOLD) + "Coins: " + String.valueOf(ChatColor.YELLOW) + balance);
                return true;
            }
            sender.sendMessage(String.valueOf(ChatColor.RED) + "Solo i player possono usare questo comando.");
            return true;
        }
        sender.sendMessage(String.valueOf(ChatColor.RED) + "Usa: /coins set|add|remove|reset <player> <amount>");
        return true;
    }

    private boolean isAdminSub(String sub) {
        return sub.equals("set") || sub.equals("add") || sub.equals("remove") || sub.equals("reset");
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            if (!sender.hasPermission("coins.admin")) {
                return Collections.emptyList();
            }
            return this.filterStartsWith(Arrays.asList("set", "add", "remove", "reset"), args[0]);
        }
        if (args.length == 2 && this.isAdminSub(args[0].toLowerCase())) {
            ArrayList<String> names = new ArrayList<String>();
            for (Player player : Bukkit.getOnlinePlayers()) {
                names.add(player.getName());
            }
            return this.filterStartsWith(names, args[1]);
        }
        if (args.length == 3 && (args[0].equalsIgnoreCase("set") || args[0].equalsIgnoreCase("add") || args[0].equalsIgnoreCase("remove"))) {
            return this.filterStartsWith(Arrays.asList("1", "5", "10", "20", "50"), args[2]);
        }
        return Collections.emptyList();
    }

    private List<String> filterStartsWith(List<String> values, String prefix) {
        if (prefix == null || prefix.isEmpty()) {
            return values;
        }
        ArrayList<String> result = new ArrayList<String>();
        String lower = prefix.toLowerCase();
        for (String value : values) {
            if (!value.toLowerCase().startsWith(lower)) continue;
            result.add(value);
        }
        return result;
    }
}

