/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.api.commands;

import github.scarsz.discordsrv.api.commands.PluginSlashCommand;
import java.util.Set;

public interface SlashCommandProvider {
    public Set<PluginSlashCommand> getSlashCommands();
}

