/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.md_5.bungee.api.chat.BaseComponent
 *  net.md_5.bungee.api.chat.ClickEvent
 *  net.md_5.bungee.api.chat.ClickEvent$Action
 *  net.md_5.bungee.api.chat.ComponentBuilder
 *  net.md_5.bungee.api.chat.HoverEvent
 *  net.md_5.bungee.api.chat.HoverEvent$Action
 *  net.md_5.bungee.api.chat.TextComponent
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.Sound
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.TabExecutor
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.event.player.AsyncPlayerChatEvent
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.java.JavaPlugin
 */
package me.cosmoassistenza;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.md_5.bungee.api.chat.BaseComponent;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.ComponentBuilder;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

public class AssistenzaPlugin
extends JavaPlugin
implements Listener,
TabExecutor {
    private final Set<UUID> inAttesaRichiesta = new HashSet<UUID>();

    public void onEnable() {
        this.saveDefaultConfig();
        if (this.getCommand("assistenza") != null) {
            this.getCommand("assistenza").setExecutor((CommandExecutor)this);
        }
        if (this.getCommand("assistenza_tp") != null) {
            this.getCommand("assistenza_tp").setExecutor((CommandExecutor)this);
        }
        Bukkit.getPluginManager().registerEvents((Listener)this, (Plugin)this);
    }

    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (cmd.getName().equalsIgnoreCase("assistenza_tp")) {
            if (!(sender instanceof Player)) {
                return true;
            }
            Player staff = (Player)sender;
            if (args.length != 1) {
                staff.sendMessage("\u00a7cUtilizzo: /assistenza_tp <player>");
                return true;
            }
            Player target = Bukkit.getPlayer((String)args[0]);
            if (target == null) {
                staff.sendMessage("\u00a7cQuel giocatore non \u00e8 online!");
                return true;
            }
            staff.teleport(target.getLocation());
            target.sendMessage("\u00a7b[\u00a73\u1d00\ua731\ua731\u026a\ua731\u1d1b\u1d07\u0274\u1d22\u1d00\u00a7b] \u00a7bUno staffer ha letto la tua richiesta e si \u00e8 tippato!! \u00a7b\u00a7lstaffer : \u00a7f\u00a7l" + staff.getName());
            staff.sendMessage("\u00a7b[\u00a73\u1d00\ua731\ua731\u026a\ua731\u1d1b\u1d07\u0274\u1d22\u1d00\u00a7b] \u00a7bStai facendo assistenza a  \u00a7f\u00a7l" + target.getName());
            target.playSound(target.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
            staff.playSound(staff.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
            return true;
        }
        if (cmd.getName().equalsIgnoreCase("assistenza")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("\u00a7cSolo i player possono usare questo comando!");
                return true;
            }
            Player p = (Player)sender;
            Inventory gui = Bukkit.createInventory(null, (int)27, (String)"\u00a78Richiesta Assistenza");
            ItemStack glassPane = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
            ItemMeta glassMeta = glassPane.getItemMeta();
            glassMeta.setDisplayName(" ");
            glassPane.setItemMeta(glassMeta);
            for (int i = 0; i < 27; ++i) {
                gui.setItem(i, glassPane);
            }
            gui.setItem(10, this.creaBottone(Material.WARPED_FENCE, "\u00a7c\u00a7l\ua731\u1d0f\u0274\u1d0f \u0299\u029f\u1d0f\u1d04\u1d04\u1d00\u1d1b\u1d0f", "\u00a77Clicca qui se sei bloccato"));
            gui.setItem(11, this.creaBottone(Material.WARPED_FENCE, "\u00a7e\u00a7l\u1d00\ua731\ua731\u026a\ua731\u1d1b\u1d07\u0274\u1d22\u1d00 \u0262\u1d07\u0274\u1d07\u0280\u1d00\u029f\u1d07", "\u00a77Hai bisogno di aiuto generale"));
            gui.setItem(12, this.creaBottone(Material.WARPED_FENCE, "\u00a7b\u00a7l\u1d00\ua731\ua731\u026a\ua731\u1d1b\u1d07\u0274\u1d22\u1d00 \u1d00\u1d22\u026a\u1d0f\u0274\u026a", "\u00a77Hai bisogno di chiarimenti per un'azione"));
            gui.setItem(13, this.creaBottone(Material.WARPED_FENCE, "\u00a74\u00a7l\ua731\u1d07\u0262\u0274\u1d00\u029f\u1d00 \u0299\u1d1c\u0262", "\u00a77Hai trovato un bug?"));
            gui.setItem(14, this.creaBottone(Material.WARPED_FENCE, "\u00a7a\u00a7l\ua731\u1d1c\u0262\u0262\u1d07\u0280\u026a\u1d0d\u1d07\u0274\u1d1b\u1d0f", "\u00a77Vuoi suggerire qualcosa?"));
            gui.setItem(15, this.creaBottone(Material.WARPED_FENCE, "\u00a7c\u00a7l\u0280\u1d07\u1d18\u1d0f\u0280\u1d1b \u0262\u026a\u1d0f\u1d04\u1d00\u1d1b\u1d0f\u0280\u1d07", "\u00a77Hai bisogno di segnalare un player"));
            gui.setItem(16, this.creaBottone(Material.WARPED_FENCE, "\u00a74\u00a7l\ua731\u1d00\u0274\u1d22\u026a\u1d0f\u0274\u026a", "\u00a77Hai bisogno di un Ban/Kick/Mute"));
            p.openInventory(gui);
            return true;
        }
        return true;
    }

    private ItemStack creaBottone(Material mat, String nome, String lore) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(nome);
        meta.setLore(Arrays.asList("", lore));
        item.setItemMeta(meta);
        return item;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (e.getView().getTitle().equals("\u00a78Richiesta Assistenza")) {
            e.setCancelled(true);
            if (!(e.getWhoClicked() instanceof Player)) {
                return;
            }
            Player p = (Player)e.getWhoClicked();
            if (e.getCurrentItem() == null || !e.getCurrentItem().hasItemMeta()) {
                return;
            }
            String titolo = e.getCurrentItem().getItemMeta().getDisplayName();
            if (titolo.equals("\u00a7c\u00a7l\ua731\u1d0f\u0274\u1d0f \u0299\u029f\u1d0f\u1d04\u1d04\u1d00\u1d1b\u1d0f")) {
                this.inviaMessaggioStaff(p, "\u00a7cIl cittadino \u00a7f" + p.getName() + " \u00a7c\u00e8 \u0299\u029f\u1d0f\u1d04\u1d04\u1d00\u1d1b\u1d0f!");
                this.confermaGiocatore(p);
            } else {
                if (titolo.equals("\u00a7e\u00a7l\u1d00\ua731\ua731\u026a\ua731\u1d1b\u1d07\u0274\u1d22\u1d00 \u0262\u1d07\u0274\u1d07\u0280\u1d00\u029f\u1d07")) {
                    p.closeInventory();
                    p.sendMessage("\u00a7e\u270e \ua731\u1d04\u0280\u026a\u1d20\u026a Q\u1d1c\u026a \u029f\u1d00 \u1d1b\u1d1c\u1d00 \u0280\u026a\u1d04\u029c\u026a\u1d07\ua731\u1d1b\u1d00.");
                    this.inAttesaRichiesta.add(p.getUniqueId());
                    return;
                }
                if (titolo.equals("\u00a7b\u00a7l\u1d00\ua731\ua731\u026a\ua731\u1d1b\u1d07\u0274\u1d22\u1d00 \u1d00\u1d22\u026a\u1d0f\u0274\u026a")) {
                    this.inviaMessaggioStaff(p, "\u00a7bIl cittadino \u00a7f" + p.getName() + " \u00a7b\u1d04\u029c\u026a\u1d07\u1d05\u1d07 \u1d04\u029c\u026a\u1d00\u0280\u026a\u1d0d\u1d07\u0274\u1d1b\u026a \u1d18\u1d07\u0280 \u1d1c\u0274'\u1d00\u1d22\u026a\u1d0f\u0274\u1d07 \u0280\u1d18!");
                    this.confermaGiocatore(p);
                } else if (titolo.equals("\u00a74\u00a7l\ua731\u1d07\u0262\u0274\u1d00\u029f\u1d00 \u0299\u1d1c\u0262")) {
                    this.inviaMessaggioStaff(p, "\u00a7bIl cittadino \u00a7f" + p.getName() + " \u00a7c\u1d20\u1d1c\u1d0f\u029f\u1d07 \ua731\u1d07\u0262\u0274\u1d00\u029f\u1d00\u0280\u1d07 \u1d1c\u0274 \u0299\u1d1c\u0262");
                    this.confermaGiocatore(p);
                } else if (titolo.equals("\u00a7a\u00a7l\ua731\u1d1c\u0262\u0262\u1d07\u0280\u026a\u1d0d\u1d07\u0274\u1d1b\u1d0f")) {
                    this.inviaMessaggioStaff(p, "\u00a7bIl cittadino \u00a7f" + p.getName() + " \u00a7a\u029c\u1d00 \u1d1c\u0274 \ua731\u1d1c\u0262\u0262\u1d07\u0280\u026a\u1d0d\u1d07\u0274\u1d1b\u1d0f!");
                    this.confermaGiocatore(p);
                } else if (titolo.equals("\u00a7c\u00a7l\u0280\u1d07\u1d18\u1d0f\u0280\u1d1b \u0262\u026a\u1d0f\u1d04\u1d00\u1d1b\u1d0f\u0280\u1d07")) {
                    this.inviaMessaggioStaff(p, "\u00a7bIl cittadino \u00a7f" + p.getName() + " \u00a7c\u029c\u1d00 \ua731\u1d07\u0262\u0274\u1d00\u029f\u1d00\u1d1b\u1d0f \u1d1c\u0274 \u1d18\u029f\u1d00\u028f\u1d07\u0280!");
                    this.confermaGiocatore(p);
                } else if (titolo.equals("\u00a74\u00a7l\ua731\u1d00\u0274\u1d22\u026a\u1d0f\u0274\u026a")) {
                    this.inviaMessaggioStaff(p, "\u00a7bIl cittadino \u00a7f" + p.getName() + " \u00a7c\u1d04\u029c\u026a\u1d07\u1d05\u1d07 \u1d1c\u0274'\u1d00\u1d22\u026a\u1d0f\u0274\u1d07 \u1d05\u026a\ua731\u1d04\u026a\u1d18\u029f\u026a\u0274\u1d00\u0280\u1d07!");
                    this.confermaGiocatore(p);
                }
            }
            p.closeInventory();
        }
    }

    @EventHandler
    public void onChat(AsyncPlayerChatEvent e) {
        Player p = e.getPlayer();
        if (this.inAttesaRichiesta.contains(p.getUniqueId())) {
            e.setCancelled(true);
            String richiesta = e.getMessage();
            this.inviaMessaggioStaff(p, "\u00a7b \u00a73Richiede\u00a7b: \u00a7f" + richiesta);
            p.sendMessage("\u00a73\u00a7l\u029f\u1d00 \u1d1b\u1d1c\u1d00 \u0280\u026a\u1d04\u029c\u026a\u1d07\ua731\u1d1b\u1d00 \u00e8 \ua731\u1d1b\u1d00\u1d1b\u1d00 \u026a\u0274\u1d20\u026a\u1d00\u1d1b\u1d00 \u1d00\u029f\u029f\u1d0f \ua731\u1d1b\u1d00\ua730\ua730!");
            this.inAttesaRichiesta.remove(p.getUniqueId());
        }
    }

    private void inviaMessaggioStaff(Player richiedente, String messaggio) {
        String prefisso = "\u00a7b[\u00a73\u1d00\ua731\ua731\u026a\ua731\u1d1b\u1d07\u0274\u1d22\u1d00\u00a7b]";
        for (Player staff : Bukkit.getOnlinePlayers()) {
            if (!staff.hasPermission("assistenza.staff")) continue;
            TextComponent base = new TextComponent(prefisso + " " + messaggio);
            TextComponent tippa = new TextComponent(" \u00a7a[\u1d1b\u026a\u1d18\u1d18\u1d00\u1d1b\u026a]");
            tippa.setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/assistenza_tp " + richiedente.getName()));
            tippa.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new ComponentBuilder("\u00a73\u1d04\u029f\u026a\u1d04\u1d04\u1d00 \u1d18\u1d07\u0280 \u1d1b\u1d07\u029f\u1d07\u1d18\u1d0f\u0280\u1d1b\u1d00\u0280\u1d1b\u026a \u1d05\u1d00 \u00a7f" + richiedente.getName()).create()));
            base.addExtra((BaseComponent)tippa);
            staff.spigot().sendMessage((BaseComponent)base);
        }
    }

    private void confermaGiocatore(Player p) {
        p.sendMessage("\u00a7b\u00a7lHai richiesto assistenza allo staff!");
        p.sendMessage("");
        p.sendMessage("\u00a79\u00a7l~-~-~-~-~-~-~~-~-~-~-~-~-~~-~-~-~-~-~-~");
        p.sendMessage("");
        p.sendMessage("\u00a73        Uno staffer ti assister\u00e0 a momenti!");
        p.sendMessage(" ");
        p.sendMessage("\u00a79\u00a7l~-~-~-~-~-~-~~-~-~-~-~-~-~~-~-~-~-~-~-~");
        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
    }
}

