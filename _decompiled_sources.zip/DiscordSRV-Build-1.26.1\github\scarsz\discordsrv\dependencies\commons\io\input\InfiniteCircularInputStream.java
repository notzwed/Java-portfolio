/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.io.input;

import github.scarsz.discordsrv.dependencies.commons.io.input.CircularInputStream;

public class InfiniteCircularInputStream
extends CircularInputStream {
    public InfiniteCircularInputStream(byte[] repeatContent) {
        super(repeatContent, -1L);
    }
}

