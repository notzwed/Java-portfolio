/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.collections4.iterators;

import github.scarsz.discordsrv.dependencies.commons.collections4.functors.UniquePredicate;
import github.scarsz.discordsrv.dependencies.commons.collections4.iterators.FilterIterator;
import java.util.Iterator;

public class UniqueFilterIterator<E>
extends FilterIterator<E> {
    public UniqueFilterIterator(Iterator<? extends E> iterator) {
        super(iterator, UniquePredicate.uniquePredicate());
    }
}

