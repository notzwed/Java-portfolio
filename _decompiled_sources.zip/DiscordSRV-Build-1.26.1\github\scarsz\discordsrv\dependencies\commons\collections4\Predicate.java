/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.collections4;

public interface Predicate<T> {
    public boolean evaluate(T var1);
}

