/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.CommandSender
 */
package github.scarsz.discordsrv.api.events;

import github.scarsz.discordsrv.api.events.Event;
import org.bukkit.command.CommandSender;

public class ConfigReloadedEvent
extends Event {
    private final CommandSender requester;

    public ConfigReloadedEvent(CommandSender requester) {
        this.requester = requester;
    }

    public CommandSender getRequester() {
        return this.requester;
    }
}

