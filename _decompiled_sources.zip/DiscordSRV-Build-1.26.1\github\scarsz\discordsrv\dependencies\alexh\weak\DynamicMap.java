/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.alexh.weak;

import github.scarsz.discordsrv.dependencies.alexh.LiteJoiner;
import github.scarsz.discordsrv.dependencies.alexh.weak.AbstractDynamic;
import github.scarsz.discordsrv.dependencies.alexh.weak.ChildAbsence;
import github.scarsz.discordsrv.dependencies.alexh.weak.Describer;
import github.scarsz.discordsrv.dependencies.alexh.weak.Dynamic;
import github.scarsz.discordsrv.dependencies.alexh.weak.DynamicChild;
import github.scarsz.discordsrv.dependencies.alexh.weak.DynamicChildLogic;
import github.scarsz.discordsrv.dependencies.alexh.weak.ParentAbsence;
import java.util.Map;
import java.util.stream.Stream;

class DynamicMap
extends AbstractDynamic<Map<?, ?>>
implements Dynamic,
Describer {
    public DynamicMap(Map<?, ?> inner) {
        super(inner);
    }

    @Override
    public Dynamic get(Object childKey) {
        if (((Map)this.inner).isEmpty()) {
            return new ParentAbsence.Empty<DynamicMap>(this, childKey);
        }
        if (!((Map)this.inner).containsKey(childKey)) {
            String keyString;
            if (childKey instanceof String) {
                for (Map.Entry entry : ((Map)this.inner).entrySet()) {
                    if (!childKey.equals(entry.getKey().toString())) continue;
                    return entry.getValue() != null ? DynamicChild.from(this, childKey, entry.getValue()) : new ChildAbsence.Null(this, childKey);
                }
            }
            if (((Map)this.inner).containsKey(keyString = childKey.toString())) {
                Object val = ((Map)this.inner).get(keyString);
                return val != null ? DynamicChild.from(this, keyString, val) : new ChildAbsence.Null(this, (Object)keyString);
            }
            return new ChildAbsence.Missing<DynamicMap>(this, childKey);
        }
        Object val = ((Map)this.inner).get(childKey);
        return val != null ? DynamicChild.from(this, childKey, val) : new ChildAbsence.Null(this, childKey);
    }

    @Override
    public Stream<Dynamic> children() {
        return ((Map)this.inner).keySet().stream().map(this::get);
    }

    @Override
    public String describe() {
        if (((Map)this.inner).isEmpty()) {
            return "Empty-Map";
        }
        return "Map" + ((Map)this.inner).keySet().toString();
    }

    @Override
    public Object keyLiteral() {
        return "root";
    }

    public String toString() {
        return this.keyLiteral() + ":" + this.describe();
    }

    static class Child
    extends DynamicMap
    implements DynamicChild {
        private final Dynamic parent;
        private final Object key;

        Child(Dynamic parent, Object key, Map inner) {
            super(inner);
            this.parent = parent;
            this.key = key;
        }

        @Override
        public Dynamic parent() {
            return this.parent;
        }

        @Override
        public Object keyLiteral() {
            return this.key;
        }

        @Override
        public String toString() {
            return LiteJoiner.on("->").join(DynamicChildLogic.using(this).getAscendingKeyChainWithRoot()) + ":" + this.describe();
        }
    }
}

