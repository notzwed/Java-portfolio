/*
 * Decompiled with CFR 0.152.
 */
package com.hrakaroo.glob;

import com.hrakaroo.glob.MatchingEngine;

class EndsWithEngine
implements MatchingEngine {
    final char[] lowerCase;
    final char[] upperCase;
    final boolean[] matchOne;
    final int length;

    protected EndsWithEngine(char[] lowerCase, char[] upperCase, boolean[] matchOne, int length) {
        this.lowerCase = lowerCase;
        this.upperCase = upperCase;
        this.matchOne = matchOne;
        this.length = length;
    }

    @Override
    public boolean matches(String string) {
        if (string == null) {
            return false;
        }
        if (string.length() < this.length - 1) {
            return false;
        }
        int charsIndex = string.length() - 1;
        for (int patternIndex = this.length - 1; patternIndex > 0; --patternIndex) {
            if (!this.matchOne[patternIndex] && string.charAt(charsIndex) != this.lowerCase[patternIndex] && string.charAt(charsIndex) != this.upperCase[patternIndex]) {
                return false;
            }
            --charsIndex;
        }
        return true;
    }

    @Override
    public int matchingSizeInBytes() {
        return 8 + this.staticSizeInBytes();
    }

    @Override
    public int staticSizeInBytes() {
        return this.lowerCase.length * 5 + 4;
    }
}

