/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.alexh.weak;

import github.scarsz.discordsrv.dependencies.alexh.weak.Dynamic;
import github.scarsz.discordsrv.dependencies.alexh.weak.DynamicChild;

public abstract class AbstractDynamic<T>
implements Dynamic {
    protected final T inner;

    public AbstractDynamic(T inner) {
        this.inner = inner;
    }

    @Override
    public boolean isPresent() {
        return true;
    }

    @Override
    public Object asObject() {
        return this.inner;
    }

    public int hashCode() {
        return this.inner.hashCode();
    }

    protected abstract Object keyLiteral();

    public Dynamic key() {
        return DynamicChild.key(this, this.keyLiteral());
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        AbstractDynamic other = (AbstractDynamic)o;
        return this.inner.equals(other.inner);
    }
}

