/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.api.events;

import github.scarsz.discordsrv.api.Cancellable;
import github.scarsz.discordsrv.api.events.DiscordEvent;
import github.scarsz.discordsrv.dependencies.jda.api.events.message.guild.GuildMessageReceivedEvent;

public class DiscordConsoleCommandPreProcessEvent
extends DiscordEvent<GuildMessageReceivedEvent>
implements Cancellable {
    private boolean sentInConsoleChannel;
    private boolean cancelled;
    private String command;

    public DiscordConsoleCommandPreProcessEvent(GuildMessageReceivedEvent jdaEvent, String command, boolean sentInConsoleChannel) {
        super(jdaEvent.getJDA(), jdaEvent);
        this.sentInConsoleChannel = sentInConsoleChannel;
        this.cancelled = false;
        this.command = command;
    }

    public boolean isSentInConsoleChannel() {
        return this.sentInConsoleChannel;
    }

    @Override
    public boolean isCancelled() {
        return this.cancelled;
    }

    @Override
    public void setCancelled(boolean cancelled) {
        this.cancelled = cancelled;
    }

    public String getCommand() {
        return this.command;
    }

    public void setCommand(String command) {
        this.command = command;
    }
}

