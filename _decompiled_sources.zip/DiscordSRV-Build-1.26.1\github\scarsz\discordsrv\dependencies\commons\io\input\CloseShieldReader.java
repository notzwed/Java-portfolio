/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.io.input;

import github.scarsz.discordsrv.dependencies.commons.io.input.ClosedReader;
import github.scarsz.discordsrv.dependencies.commons.io.input.ProxyReader;
import java.io.Reader;

public class CloseShieldReader
extends ProxyReader {
    public static CloseShieldReader wrap(Reader reader) {
        return new CloseShieldReader(reader);
    }

    @Deprecated
    public CloseShieldReader(Reader reader) {
        super(reader);
    }

    @Override
    public void close() {
        this.in = ClosedReader.CLOSED_READER;
    }
}

