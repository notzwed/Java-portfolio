/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.collections4;

import github.scarsz.discordsrv.dependencies.commons.collections4.IterableGet;
import github.scarsz.discordsrv.dependencies.commons.collections4.Put;
import java.util.Map;

public interface IterableMap<K, V>
extends Map<K, V>,
Put<K, V>,
IterableGet<K, V> {
}

