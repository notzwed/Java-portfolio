/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package it.marco.businessmanager.service;

import it.marco.businessmanager.BusinessManagerPlugin;
import it.marco.businessmanager.data.DataStore;
import it.marco.businessmanager.economy.EconomyService;
import it.marco.businessmanager.model.Company;
import it.marco.businessmanager.model.Role;
import it.marco.businessmanager.model.SalaryConfig;
import it.marco.businessmanager.util.MessageManager;
import java.util.ArrayList;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class SalaryScheduler {
    private final BusinessManagerPlugin plugin;
    private final DataStore dataStore;
    private final EconomyService economyService;
    private final MessageManager messages;
    private BukkitTask task;

    public SalaryScheduler(BusinessManagerPlugin plugin, DataStore dataStore, EconomyService economyService, MessageManager messages) {
        this.plugin = plugin;
        this.dataStore = dataStore;
        this.economyService = economyService;
        this.messages = messages;
    }

    public void start() {
        if (this.task != null) {
            this.task.cancel();
        }
        this.task = new BukkitRunnable(){

            public void run() {
                SalaryScheduler.this.processSalaries();
            }
        }.runTaskTimer((Plugin)this.plugin, 1200L, 1200L);
    }

    public void stop() {
        if (this.task != null) {
            this.task.cancel();
        }
    }

    public boolean runForCompany(Company company, boolean force) {
        Player director;
        SalaryConfig salary = company.getSalaryConfig();
        if (salary == null) {
            return false;
        }
        if (!salary.isEnabled() && !force) {
            return false;
        }
        long now = System.currentTimeMillis();
        long intervalMillis = (long)salary.getIntervalMinutes() * 60L * 1000L;
        if (!force && now - salary.getLastPaidEpoch() < intervalMillis) {
            return false;
        }
        boolean payOffline = this.plugin.getConfig().getBoolean("salary.pay-offline", false);
        ArrayList<UUID> receivers = new ArrayList<UUID>();
        for (UUID uuid : company.getMembers().keySet()) {
            Player player;
            Role role = company.getRole(uuid);
            if (!salary.getPayRoles().contains((Object)role) || !payOffline && ((player = Bukkit.getPlayer((UUID)uuid)) == null || !player.isOnline())) continue;
            receivers.add(uuid);
        }
        if (receivers.isEmpty()) {
            return false;
        }
        double total = salary.getAmount() * (double)receivers.size();
        if (company.getBalance() < total) {
            salary.setLastPaidEpoch(now);
            boolean notify = this.plugin.getConfig().getBoolean("salary.notify-on-failed-payment", true);
            if (notify) {
                Player director2;
                Player player = director2 = company.getDirector() != null ? Bukkit.getPlayer((UUID)company.getDirector()) : null;
                if (director2 != null && director2.isOnline()) {
                    director2.sendMessage(this.messages.get("salary-failed"));
                }
            }
            return false;
        }
        company.setBalance(company.getBalance() - total);
        for (UUID uuid : receivers) {
            Player player;
            this.economyService.depositPlayer(uuid, salary.getAmount());
            OfflinePlayer offline = Bukkit.getOfflinePlayer((UUID)uuid);
            if (!offline.isOnline() || (player = offline.getPlayer()) == null) continue;
            player.sendMessage(this.messages.format("salary-received", Map.of("amount", this.economyService.format(salary.getAmount()))));
        }
        Player player = director = company.getDirector() != null ? Bukkit.getPlayer((UUID)company.getDirector()) : null;
        if (director != null && director.isOnline()) {
            director.sendMessage(this.messages.format("salary-paid", Map.of("count", String.valueOf(receivers.size()), "amount", this.economyService.format(total))));
        }
        salary.setLastPaidEpoch(now);
        return true;
    }

    private void processSalaries() {
        for (Company company : this.dataStore.getCompanies()) {
            this.runForCompany(company, false);
        }
    }
}

