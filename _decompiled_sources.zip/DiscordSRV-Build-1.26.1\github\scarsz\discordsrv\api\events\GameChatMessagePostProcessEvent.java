/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Cancellable
 *  org.bukkit.event.Event
 */
package github.scarsz.discordsrv.api.events;

import github.scarsz.discordsrv.api.events.GameEvent;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;

public class GameChatMessagePostProcessEvent
extends GameEvent<Event>
implements Cancellable {
    private boolean cancelled;
    private String channel;
    private String processedMessage;

    public GameChatMessagePostProcessEvent(String channel, String processedMessage, Player player, boolean cancelled, Event event) {
        super(player, event);
        this.channel = channel;
        this.processedMessage = processedMessage;
        this.setCancelled(cancelled);
    }

    @Deprecated
    public GameChatMessagePostProcessEvent(String channel, String processedMessage, Player player, boolean cancelled) {
        this(channel, processedMessage, player, cancelled, null);
    }

    public boolean isCancelled() {
        return this.cancelled;
    }

    public void setCancelled(boolean cancelled) {
        this.cancelled = cancelled;
    }

    public String getChannel() {
        return this.channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public String getProcessedMessage() {
        return this.processedMessage;
    }

    public void setProcessedMessage(String processedMessage) {
        this.processedMessage = processedMessage;
    }
}

