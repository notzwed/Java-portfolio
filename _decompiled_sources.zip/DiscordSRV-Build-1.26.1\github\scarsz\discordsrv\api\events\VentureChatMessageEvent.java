/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  mineverse.Aust1n46.chat.api.events.VentureChatEvent
 */
package github.scarsz.discordsrv.api.events;

import github.scarsz.discordsrv.api.events.Event;
import mineverse.Aust1n46.chat.api.events.VentureChatEvent;

abstract class VentureChatMessageEvent
extends Event {
    private final VentureChatEvent ventureChatEvent;

    VentureChatMessageEvent(VentureChatEvent ventureChatEvent) {
        this.ventureChatEvent = ventureChatEvent;
    }

    public VentureChatEvent getVentureChatEvent() {
        return this.ventureChatEvent;
    }
}

