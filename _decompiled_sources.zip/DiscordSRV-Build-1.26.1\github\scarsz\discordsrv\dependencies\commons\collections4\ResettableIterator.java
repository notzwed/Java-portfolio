/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.collections4;

import java.util.Iterator;

public interface ResettableIterator<E>
extends Iterator<E> {
    public void reset();
}

