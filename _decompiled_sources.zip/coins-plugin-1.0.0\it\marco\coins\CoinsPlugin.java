/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.java.JavaPlugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package it.marco.coins;

import it.marco.coins.CoinsCommand;
import it.marco.coins.CoinsManager;
import it.marco.coins.CoinsPlaceholder;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.List;
import java.util.Locale;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class CoinsPlugin
extends JavaPlugin {
    private CoinsManager coinsManager;
    private BukkitTask rewardTask;
    private int coinsPerInterval;
    private int intervalMinutes;
    private DecimalFormat decimalFormat;
    private DecimalFormat compactFormat;
    private boolean compactEnabled;
    private int compactMin;
    private String[] compactSuffixes;

    public void onEnable() {
        this.saveDefaultConfig();
        this.loadSettings();
        this.coinsManager = new CoinsManager(this);
        this.coinsManager.load();
        CoinsCommand command = new CoinsCommand(this);
        if (this.getCommand("coins") != null) {
            this.getCommand("coins").setExecutor((CommandExecutor)command);
            this.getCommand("coins").setTabCompleter((TabCompleter)command);
        }
        if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new CoinsPlaceholder(this).register();
            this.getLogger().info("PlaceholderAPI trovato: placeholder %coins_balance% e %coins_formatted% attivi.");
        }
        this.startRewardTask();
    }

    public void onDisable() {
        if (this.rewardTask != null) {
            this.rewardTask.cancel();
        }
        if (this.coinsManager != null) {
            this.coinsManager.save();
        }
    }

    public CoinsManager getCoinsManager() {
        return this.coinsManager;
    }

    public int getCoinsPerInterval() {
        return this.coinsPerInterval;
    }

    public int getIntervalMinutes() {
        return this.intervalMinutes;
    }

    public String formatCoins(int amount) {
        if (this.compactEnabled) {
            return this.formatCompact(amount);
        }
        return this.decimalFormat.format(amount);
    }

    private void loadSettings() {
        this.coinsPerInterval = Math.max(0, this.getConfig().getInt("coins-per-interval", 5));
        this.intervalMinutes = Math.max(0, this.getConfig().getInt("interval-minutes", 10));
        String pattern = this.getConfig().getString("format", "#,###");
        String localeTag = this.getConfig().getString("format-locale", "it-IT");
        Locale locale = this.parseLocale(localeTag);
        DecimalFormatSymbols symbols = new DecimalFormatSymbols(locale);
        this.decimalFormat = new DecimalFormat(pattern, symbols);
        this.decimalFormat.setGroupingUsed(true);
        this.decimalFormat.setMaximumFractionDigits(0);
        this.compactEnabled = this.getConfig().getBoolean("compact.enabled", true);
        this.compactMin = Math.max(1000, this.getConfig().getInt("compact.min", 1000));
        int compactDecimals = Math.max(0, this.getConfig().getInt("compact.decimals", 1));
        this.compactFormat = new DecimalFormat();
        this.compactFormat.setDecimalFormatSymbols(symbols);
        this.compactFormat.setGroupingUsed(false);
        this.compactFormat.setMaximumFractionDigits(compactDecimals);
        this.compactFormat.setMinimumFractionDigits(0);
        this.compactFormat.setRoundingMode(RoundingMode.HALF_UP);
        List suffixList = this.getConfig().getStringList("compact.suffixes");
        this.compactSuffixes = suffixList.isEmpty() ? new String[]{"k", "M", "B", "T"} : suffixList.toArray(new String[0]);
    }

    private String formatCompact(int amount) {
        int suffixIndex;
        long value = amount;
        long abs = Math.abs(value);
        if (abs < (long)this.compactMin) {
            return this.decimalFormat.format(value);
        }
        double scaled = abs;
        for (suffixIndex = -1; scaled >= 1000.0 && suffixIndex < this.compactSuffixes.length - 1; scaled /= 1000.0, ++suffixIndex) {
        }
        if (suffixIndex < 0) {
            return this.decimalFormat.format(value);
        }
        double signed = value < 0L ? -scaled : scaled;
        return this.compactFormat.format(signed) + this.compactSuffixes[suffixIndex];
    }

    private Locale parseLocale(String value) {
        if (value == null) {
            return Locale.getDefault();
        }
        String normalized = value.trim();
        if (normalized.isEmpty()) {
            return Locale.getDefault();
        }
        String[] parts = normalized.split("[-_]");
        if (parts.length == 1) {
            return new Locale(parts[0]);
        }
        if (parts.length == 2) {
            return new Locale(parts[0], parts[1]);
        }
        return new Locale(parts[0], parts[1], parts[2]);
    }

    private void startRewardTask() {
        if (this.coinsPerInterval <= 0) {
            this.getLogger().warning("coins-per-interval e' <= 0. Task ricompensa disabilitato.");
            return;
        }
        if (this.intervalMinutes <= 0) {
            this.getLogger().warning("interval-minutes e' <= 0. Task ricompensa disabilitato.");
            return;
        }
        long intervalTicks = (long)this.intervalMinutes * 60L * 20L;
        this.rewardTask = new BukkitRunnable(){

            public void run() {
                for (Player player : Bukkit.getOnlinePlayers()) {
                    CoinsPlugin.this.coinsManager.addBalance(player.getUniqueId(), CoinsPlugin.this.coinsPerInterval);
                }
                CoinsPlugin.this.coinsManager.save();
            }
        }.runTaskTimer((Plugin)this, intervalTicks, intervalTicks);
    }
}

