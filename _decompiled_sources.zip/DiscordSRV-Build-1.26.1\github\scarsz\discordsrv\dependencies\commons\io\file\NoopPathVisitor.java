/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.io.file;

import github.scarsz.discordsrv.dependencies.commons.io.file.SimplePathVisitor;

public class NoopPathVisitor
extends SimplePathVisitor {
    public static final NoopPathVisitor INSTANCE = new NoopPathVisitor();
}

