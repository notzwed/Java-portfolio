/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.configuralize;

import github.scarsz.configuralize.Source;

public class ParseException
extends Exception {
    public ParseException(Source source, Throwable cause) {
        super("Error parsing config file " + source.getFile().getName() + ": " + cause.getMessage(), cause);
    }
}

