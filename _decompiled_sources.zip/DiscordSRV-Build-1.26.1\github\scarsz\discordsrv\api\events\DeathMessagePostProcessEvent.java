/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Cancellable
 *  org.bukkit.event.entity.PlayerDeathEvent
 */
package github.scarsz.discordsrv.api.events;

import github.scarsz.discordsrv.api.events.GameEvent;
import github.scarsz.discordsrv.dependencies.jda.api.MessageBuilder;
import github.scarsz.discordsrv.dependencies.jda.api.entities.Message;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.entity.PlayerDeathEvent;

public class DeathMessagePostProcessEvent
extends GameEvent<PlayerDeathEvent>
implements Cancellable {
    private boolean cancelled;
    private final String deathMessage;
    private String channel;
    private Message discordMessage;
    private boolean usingWebhooks;
    private String webhookName;
    private String webhookAvatarUrl;

    public DeathMessagePostProcessEvent(String channel, Message discordMessage, Player player, String deathMessage, PlayerDeathEvent triggeringBukkitEvent, boolean usingWebhooks, String webhookName, String webhookAvatarUrl, boolean cancelled) {
        super(player, triggeringBukkitEvent);
        this.channel = channel;
        this.discordMessage = discordMessage;
        this.deathMessage = deathMessage;
        this.usingWebhooks = usingWebhooks;
        this.webhookName = webhookName;
        this.webhookAvatarUrl = webhookAvatarUrl;
        this.setCancelled(cancelled);
    }

    @Deprecated
    public DeathMessagePostProcessEvent(String channel, Message discordMessage, Player player, String deathMessage, boolean usingWebhooks, String webhookName, String webhookAvatarUrl, boolean cancelled) {
        super(player, null);
        this.channel = channel;
        this.discordMessage = discordMessage;
        this.deathMessage = deathMessage;
        this.usingWebhooks = usingWebhooks;
        this.webhookName = webhookName;
        this.webhookAvatarUrl = webhookAvatarUrl;
        this.setCancelled(cancelled);
    }

    @Deprecated
    public DeathMessagePostProcessEvent(String channel, String processedMessage, Player player, String deathMessage, boolean cancelled) {
        super(player, null);
        this.channel = channel;
        this.discordMessage = new MessageBuilder().setContent(processedMessage).build();
        this.deathMessage = deathMessage;
        this.setCancelled(cancelled);
    }

    @Deprecated
    public String getProcessedMessage() {
        return this.discordMessage.getContentRaw();
    }

    @Deprecated
    public void setProcessedMessage(String processedMessage) {
        this.discordMessage = new MessageBuilder(processedMessage).build();
    }

    public boolean isCancelled() {
        return this.cancelled;
    }

    public void setCancelled(boolean cancelled) {
        this.cancelled = cancelled;
    }

    public String getDeathMessage() {
        return this.deathMessage;
    }

    public String getChannel() {
        return this.channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public Message getDiscordMessage() {
        return this.discordMessage;
    }

    public void setDiscordMessage(Message discordMessage) {
        this.discordMessage = discordMessage;
    }

    public boolean isUsingWebhooks() {
        return this.usingWebhooks;
    }

    public void setUsingWebhooks(boolean usingWebhooks) {
        this.usingWebhooks = usingWebhooks;
    }

    public String getWebhookName() {
        return this.webhookName;
    }

    public void setWebhookName(String webhookName) {
        this.webhookName = webhookName;
    }

    public String getWebhookAvatarUrl() {
        return this.webhookAvatarUrl;
    }

    public void setWebhookAvatarUrl(String webhookAvatarUrl) {
        this.webhookAvatarUrl = webhookAvatarUrl;
    }
}

