/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.milkbowl.vault.economy.Economy
 *  org.bukkit.Bukkit
 *  org.bukkit.OfflinePlayer
 */
package it.marco.businessmanager.economy;

import it.marco.businessmanager.economy.PlayerEconomy;
import java.util.UUID;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;

public class VaultEconomy
implements PlayerEconomy {
    private final Economy economy;

    public VaultEconomy(Economy economy) {
        this.economy = economy;
    }

    @Override
    public double getBalance(UUID uuid) {
        OfflinePlayer player = Bukkit.getOfflinePlayer((UUID)uuid);
        return this.economy.getBalance(player);
    }

    @Override
    public boolean withdraw(UUID uuid, double amount) {
        OfflinePlayer player = Bukkit.getOfflinePlayer((UUID)uuid);
        return this.economy.withdrawPlayer(player, amount).transactionSuccess();
    }

    @Override
    public void deposit(UUID uuid, double amount) {
        OfflinePlayer player = Bukkit.getOfflinePlayer((UUID)uuid);
        this.economy.depositPlayer(player, amount);
    }
}

