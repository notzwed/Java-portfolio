/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.plugin.Plugin
 */
package github.scarsz.discordsrv.commands;

import github.scarsz.discordsrv.DiscordSRV;
import github.scarsz.discordsrv.api.events.ConfigReloadedEvent;
import github.scarsz.discordsrv.commands.Command;
import github.scarsz.discordsrv.hooks.chat.TownyChatHook;
import github.scarsz.discordsrv.util.LangUtil;
import github.scarsz.discordsrv.util.MessageUtil;
import github.scarsz.discordsrv.util.UpdateUtil;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.Plugin;

public class CommandReload {
    @Command(commandNames={"reload"}, helpMessage="Reloads the config of DiscordSRV", permission="discordsrv.reload")
    public static void execute(CommandSender sender, String[] args) {
        DiscordSRV.getPlugin().reloadConfig();
        DiscordSRV.getPlugin().reloadCancellationDetector();
        DiscordSRV.getPlugin().reloadChannels();
        DiscordSRV.getPlugin().reloadRegexes();
        DiscordSRV.getPlugin().reloadRoleAliases();
        DiscordSRV.getPlugin().reloadAllowedMentions();
        DiscordSRV.api.updateSlashCommands();
        if (DiscordSRV.getPlugin().getChannelUpdater() != null) {
            DiscordSRV.getPlugin().getChannelUpdater().reload();
        }
        if (DiscordSRV.getPlugin().getAlertListener() != null) {
            DiscordSRV.getPlugin().getAlertListener().reloadAlerts();
        }
        DiscordSRV.getPlugin().getPluginHooks().stream().filter(hook -> hook instanceof TownyChatHook).forEach(hook -> ((TownyChatHook)hook).reload());
        if (!DiscordSRV.isUpdateCheckDisabled() && !DiscordSRV.updateChecked) {
            Bukkit.getScheduler().runTaskAsynchronously((Plugin)DiscordSRV.getPlugin(), UpdateUtil::checkForUpdates);
            DiscordSRV.updateChecked = true;
        }
        MessageUtil.sendMessage(sender, ChatColor.AQUA + LangUtil.InternalMessage.RELOADED.toString());
        DiscordSRV.api.callEvent(new ConfigReloadedEvent(sender));
    }
}

