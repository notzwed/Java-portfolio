/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.api.events;

public abstract class Event {
}

