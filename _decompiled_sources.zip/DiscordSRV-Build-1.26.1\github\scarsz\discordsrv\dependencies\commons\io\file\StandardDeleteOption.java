/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.io.file;

import github.scarsz.discordsrv.dependencies.commons.io.IOUtils;
import github.scarsz.discordsrv.dependencies.commons.io.file.DeleteOption;

public enum StandardDeleteOption implements DeleteOption
{
    OVERRIDE_READ_ONLY;


    public static boolean overrideReadOnly(DeleteOption[] options) {
        if (IOUtils.length((Object[])options) == 0) {
            return false;
        }
        for (DeleteOption deleteOption : options) {
            if (deleteOption != OVERRIDE_READ_ONLY) continue;
            return true;
        }
        return false;
    }
}

