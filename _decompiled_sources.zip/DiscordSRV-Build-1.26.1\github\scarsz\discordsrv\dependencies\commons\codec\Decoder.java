/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.commons.codec;

import github.scarsz.discordsrv.dependencies.commons.codec.DecoderException;

public interface Decoder {
    public Object decode(Object var1) throws DecoderException;
}

