/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.alexh.weak;

import github.scarsz.discordsrv.dependencies.alexh.LiteJoiner;
import github.scarsz.discordsrv.dependencies.alexh.weak.AbstractDynamic;
import github.scarsz.discordsrv.dependencies.alexh.weak.Describer;
import github.scarsz.discordsrv.dependencies.alexh.weak.Dynamic;
import github.scarsz.discordsrv.dependencies.alexh.weak.DynamicChild;
import github.scarsz.discordsrv.dependencies.alexh.weak.DynamicChildLogic;
import github.scarsz.discordsrv.dependencies.alexh.weak.ParentAbsence;
import java.util.stream.Stream;

class DynamicSomething
extends AbstractDynamic<Object>
implements Dynamic,
Describer {
    public DynamicSomething(Object inner) {
        super(inner);
    }

    @Override
    public Dynamic get(Object key) {
        return new ParentAbsence.Barren<DynamicSomething>(this, key);
    }

    @Override
    public String describe() {
        return this.inner.getClass().getSimpleName();
    }

    @Override
    protected Object keyLiteral() {
        return "root";
    }

    public String toString() {
        return this.keyLiteral() + ":" + this.describe();
    }

    @Override
    public Stream<Dynamic> children() {
        return Stream.empty();
    }

    static class Child
    extends DynamicSomething
    implements DynamicChild {
        private final Dynamic parent;
        private final Object key;

        Child(Dynamic parent, Object key, Object inner) {
            super(inner);
            this.parent = parent;
            this.key = key;
        }

        @Override
        public Dynamic parent() {
            return this.parent;
        }

        @Override
        public Object keyLiteral() {
            return this.key;
        }

        @Override
        public String toString() {
            return LiteJoiner.on("->").join(DynamicChildLogic.using(this).getAscendingKeyChainWithRoot()) + ":" + this.describe();
        }
    }
}

