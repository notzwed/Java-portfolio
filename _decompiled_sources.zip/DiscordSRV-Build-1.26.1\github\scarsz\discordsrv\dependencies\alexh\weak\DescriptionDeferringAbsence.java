/*
 * Decompiled with CFR 0.152.
 */
package github.scarsz.discordsrv.dependencies.alexh.weak;

import github.scarsz.discordsrv.dependencies.alexh.weak.AbstractAbsence;
import github.scarsz.discordsrv.dependencies.alexh.weak.Dynamic;
import github.scarsz.discordsrv.dependencies.alexh.weak.DynamicChild;
import github.scarsz.discordsrv.dependencies.alexh.weak.DynamicChildLogic;
import github.scarsz.discordsrv.dependencies.alexh.weak.IssueDescribingChild;
import java.util.LinkedList;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

class DescriptionDeferringAbsence
extends AbstractAbsence<DynamicChild> {
    DescriptionDeferringAbsence(DescriptionDeferringAbsence parent, Object key) {
        super(parent, key);
    }

    DescriptionDeferringAbsence(IssueDescribingChild parent, Object key) {
        super(parent, key);
    }

    @Override
    public Dynamic get(Object key) {
        return new DescriptionDeferringAbsence(this, key);
    }

    @Override
    public Object asObject() {
        LinkedList<DynamicChild> chainFromDescriber = DynamicChildLogic.using(this).getAscendingChainAllWith(DescriptionDeferringAbsence.class::isInstance);
        throw new NoSuchElementException(((IssueDescribingChild)chainFromDescriber.getFirst().parent()).describeIssue(chainFromDescriber.stream().map(child -> child.key().asObject()).collect(Collectors.toList())));
    }
}

