/*
 * Decompiled with CFR 0.152.
 */
package dev.vankka.dynamicproxy;

public class InvocationError
extends Error {
    public InvocationError(Throwable cause) {
        super(cause);
    }
}

